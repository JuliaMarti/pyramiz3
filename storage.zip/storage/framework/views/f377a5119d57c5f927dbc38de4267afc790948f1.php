

<?php $__env->startSection('title','Kart Cilpren'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->
<div id="carouselExampleIndicators" class="carousel carousel-home c-home slide d-none d-md-block" data-bs-ride="carousel">
    
    <div class="carousel-indicators" >
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="carousel-inner">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " >
                        
                        <div class="carousel-overlay"></div>
                        <div class="img-slidder" style="background-image: url(<?php echo e(asset(Storage::url($imagen->imagen))); ?>);width:50%"></div>
                        <div class="carousel-caption d-none d-md-block carousel-texto">
                            <?php echo $imagen->texto; ?>

                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<!--FIN CAROUSEL-INICIO-->

<div class="filtro-home" style="background-color:#EC3237; padding:40px;">
    <div class="container">
        <form method="GET" action="<?php echo e(route('web.home.buscar')); ?>">
            <div class="row">
                <div class="col-12 col-md-1"></div>
                <div class="col-12 col-md">
                    <select class="form-control" name="marca">
                        <option value="" selected >Marca</option>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e(old('marca') == $marca->marca ? 'selected' : ''); ?> value="<?php echo e($marca->marca); ?>"> <?php echo e($marca->marca); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div> 
                <div class="col-12 col-md">
                    <select class="form-control" name="modelo">
                        <option value="" selected >Modelo</option>
                        <?php $__currentLoopData = $modelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('modelo') == $modelo->modelo ? 'selected' : ''); ?> value="<?php echo e($modelo->modelo); ?>"> <?php echo e($modelo->modelo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div> 
                <div class="col-12 col-md">
                    <select class="form-control" name="codigo">
                        <option value="" selected >Código</option>
                        <?php $__currentLoopData = $codigos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php echo e(old('modelo') == $codigo->id ? 'selected' : ''); ?> value="<?php echo e($codigo->id); ?>"> <?php echo e($codigo->id); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div> 
                <div class="col-12 col-md-1">
                    <button> <i class="fas fa-search"></i> <span>BUSCAR</span></button>
                </div>
                <div class="col-12 col-md-1"></div>
            </div>
        </form>
    </div>
</div>

<?php if($productosFiltro): ?>
<section class="section-home-categorias section-categoria" style="margin-bottom: 24px; margin-top: 24px"> 
    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $productosFiltro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($item->show): ?>
                        <?php if($item->oferta): ?>
                            <div class="col-12 col-md-3" >
                                <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                    <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                </div>
                                    
                                <div class="text-box-categorias">
                                    <h4><?php echo e($item->nombre); ?></h4>
                                    <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($item->precio_anterior); ?></span>$<?php echo e($item->precio); ?></p>
                                </div> 
                                </a>
                                
                            </div>

                        <?php else: ?>
                            <div class="col-12 col-md-3" >
                                <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); "></div>
                                        
                                    <div class="text-box-categorias">
                                        <h4><?php echo e($item->nombre); ?></h4>
                                        <p class="precio" style="text-align: right;">$<?php echo e($item->precio); ?></p>
                                    </div> 
                                </a>
                            </div>   
                        <?php endif; ?>
                    <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php endif; ?>



<div class="container" style="margin-top:23px;">
    <div class="data-home">
        <div class="row">
            <div class="col-3" style="display: flex">
                <img src="<?php echo e(asset('img/home/camion.svg')); ?>" >  
                <p class="d-none d-md-flex">Envíos gratis a CABA con tu compra mínima de $4500</p>
            </div>
            <div class="col-3" style="display: flex">
                <img src="<?php echo e(asset('img/home/mp.svg')); ?>" >  
                <p class="d-none d-md-flex">Paga con todas tus tarjetas a través de Mercado Pago.</p>
            </div>
            <div class="col-3" style="display: flex">
                <img src="<?php echo e(asset('img/home/off.svg')); ?>" >  
                <p class="d-none d-md-flex">Descuentos en efectivo en todos los productos</p>
            </div>
            <div class="col-3" style="display: flex">
                <img src="<?php echo e(asset('img/home/cuotas.png')); ?>" >  
                <p class="d-none d-md-flex">Ahora podes llevar todo en 12 cuotas sin interés</p>
            </div>
        </div>
    </div>
</div>


<!--INICIO SECCIÓN PRODUCTOS-->


<section class="section-home-categorias"> 
    <h3 style="margin-top:40px;">Visitá nuestra amplia gama de productos</h3>
    <hr style="width: 80px;
    border: 1px solid #DA241D;
    opacity:1;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 26px;">

    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($categoria->home): ?>

                    <div class="col-12 col-md-3" style="margin-bottom:50px ">
                        <a href="<?php echo e(route('web.productos.categoria',$categoria)); ?>" style="text-decoration: none">
                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($categoria->imagen))); ?>); "></div>
                            
                        <div class="text-box-categorias">
                            <h4 ><?php echo e($categoria->nombre); ?></h4>
                        </div> 
                        </a>
                    </div>
                    
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<!--FIN SECCIÓN PRODUCTOS-->
<?php if($home->seccion_foto_show): ?>
<div class="seccion-home "  style="background: linear-gradient(to left, white 0%, white 50%, #F9F9F9 50%, #F9F9F9 100%); margin-bottom:100px;">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6">
                <div  class="imagen-seccion " style="background-image: url(<?php echo e(asset(Storage::url($home->seccion_foto_imagen))); ?>);"></div>
            </div>

            <div class="col-12 col-md-6" style="background-color: white; position: relative; padding-left:0;">
                <img src="<?php echo e(asset('img/home/seccion_foto.png')); ?>" style="max-width: 100%"> 
            </div>
        </div>
    </div>
</div>
<?php endif; ?>   

<!--INICIO SECCIÓN TRABAJOS-->


        <section class="section-home-categorias  section-categoria" style="margin-bottom:0px;"> 
            <h3 style="margin-top:40px;">NUESTRAS OFERTAS</h3>
            <hr style="width: 80px;
            border: 1px solid #DA241D;
            opacity:1;
            margin-left: auto;
            margin-right: auto;
            margin-bottom: 26px;">

            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->destacado): ?>
                        <?php if($item->show): ?>
                            <?php if($item->oferta): ?>
                                <div class="col-12 col-md-3" >
                                    <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                        <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                    </div>
                                        
                                    <div class="text-box-categorias">
                                        <h4><?php echo e($item->nombre); ?></h4>
                                        <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($item->precio_anterior); ?></span>$<?php echo e($item->precio); ?></p>
                                    </div> 
                                    </a>
                                    
                                </div>

                            <?php else: ?>
                                <div class="col-12 col-md-3" >
                                    <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); "></div>
                                            
                                        <div class="text-box-categorias">
                                            <h4><?php echo e($item->nombre); ?></h4>
                                            <p class="precio" style="text-align: right;">$<?php echo e($item->precio); ?></p>
                                        </div> 
                                    </a>
                                </div>   
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                    

                </div>
            </div>
        </section>

<!--FIN SECCIÓN TRABAJOS-->



    


<!--INICIO SECCIÓN REPRESENTANTES-->

        <section class="section-home-clientes d-none d-md-block"  style="margin-bottom:80px;"> 
            <div class="container">
                <?php $cantidadRepresentantes = count($clientes) ?>

                <div id="Cfooter" class="carousel carousel-clientes slide" data-bs-ride="carousel">
                    
                    <div class="carousel-indicators" style="bottom: -60px !important; ">

                    <?php $__currentLoopData = $clientes->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <button type="button" data-bs-target="#Cfooter" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel d-none d-md-block" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>

                    <div class="carousel-inner">
                            <?php $__currentLoopData = $clientes->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " >
                                        <div class="row">

                                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($cliente->show): ?>
                                                    <div class="col-3" style="maring-bottom 1px;">
                                                            <div class=" img-border-grey "  style="background-image: url(<?php echo e(asset(Storage::url($cliente->imagen))); ?>)">
                                                                <!--<div class="overlay"></div>-->
                                                            </div>
                                                    </div>                                      
                                                    <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/index.blade.php ENDPATH**/ ?>