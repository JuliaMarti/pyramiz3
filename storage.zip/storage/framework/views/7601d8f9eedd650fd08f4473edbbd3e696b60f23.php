

<?php $__env->startSection('title',strtoupper($categoria->nombre)); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-categoria" style="margin-bottom:65px">

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-3">
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', $item->id)); ?>" style="<?php echo e($categoria_id == $item->id ? 'color: white; background-color:#000000;' : ''); ?>" class="list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->show && $product->categoria_id == $item->id): ?>
                        <a  href="<?php echo e(route('web.productos.producto',$product)); ?>" class="list-group-item list-group-item-action list-producto" style="background-color:#F8F8F8"><?php echo e($product->nombre); ?></a>

                    <?php endif; ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <div class="col-md"></div>
            <section class="section-home-categorias col-8" style="margin-bottom: 24px"> 
                <div class="container">
                    <div class="row">

                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                <?php if($producto->show): ?>
                                <div class="col-12 col-md-6" style="margin-bottom:50px ">
                                    <a href="<?php echo e(route('web.productos.producto',$producto)); ?>" style="text-decoration: none">
                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen))); ?>); "></div>
                                        
                                    <div class="text-box-categorias">
                                        <h4><?php echo e($producto->nombre); ?></h4>
                                    </div> 
                                    </a>
                                    
                                </div>
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    </div>
                </div>
            </section>
        </div>
    </div>

</section>
<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundo-hierro\resources\views/web/productos/categoria.blade.php ENDPATH**/ ?>