

<?php $__env->startSection('title','Pyramiz'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->
<div id="carouselExampleIndicators" class="carousel carousel-home slide d-none d-md-block" data-bs-ride="carousel">
    
    <div class="fondo"></div>

    <div class="carousel-indicators">
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="carousel-inner">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> ">
                        <img class="d-block" src="<?php echo e(asset(Storage::url($imagen->imagen))); ?>" alt="First slide">
                        <div class="carousel-caption d-none d-md-block carousel-texto">
                            <h2><?php echo e($imagen->titulo); ?></h2>
                            <h3><?php echo e($imagen->subtitulo); ?></h3>

                            <p><?php echo e($imagen->texto); ?></p>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<!--FIN CAROUSEL-INICIO-->

        <?php if($home->seccion_1_show): ?>
            <div class="container home-sections">
                <div class="row">
                    <div class="col-12 col-md-6 home-sec-1">
                        <h2><?php echo $home->seccion_1_titulo; ?></h2>
                        <p><?php echo e($home->seccion_1_parrafo); ?></p>
                        <hr>
                        <div class="heaer-top-item wsp">
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($configuracion->wsp); ?>" target=”_blank”><i class="fab fa-whatsapp"></i>+<?php echo e($configuracion->wsp); ?></a>
                            <a href="mailto:<?php echo e($configuracion->email); ?>" target=”_blank”><i class="far fa-envelope"></i> <?php echo e($configuracion->email_info); ?></a>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 home-sec-2">
                        <img style="width:22%; padding-bottom:100%;" src="<?php echo e(asset('img/home/mercado_shops.png')); ?>" >
                        <h2><?php echo $home->seccion_2_titulo; ?></h2>
                        <p><?php echo e($home->seccion_2_parrafo); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?> 



<!--INICIO SECCIÓN SERVICIOS-->


        <section class="section-home-servicios"> 
            <h3>SERVICIOS</h3>
            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($servicio->home): ?>

                        <div class="col-12 col-md-6">
                            <div class="img-border-servicios" style="background-image: url(<?php echo e(asset(Storage::url($servicio->imagen))); ?>); ">
                                
                                <div class="text-box-servicios">
                                    <h4><?php echo e($servicio->titulo); ?></h4>
                                    <h5><?php echo e($servicio->subtitulo); ?></h5>
                                </div> 
                            </div>


                            <p class="nombre-noticia" ><?php echo e($servicio->descripcion); ?></p>
                        </div>

                        
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>

<!--FIN SECCIÓN SERVICIOS-->



<!--INICIO SECCIÓN NOTICIAS-->

        <section class="section-home-noticias"> 
            <h3>ÚLTIMAS NOTICIAS</h3>
            <div class="container">
                <div class="row">

                     <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($noticia->home): ?>
                        <div class="col-12 col-md-6 item-noticia">
                            <div>
                                <div class="img-border-noticias" style="background-image: url(<?php echo e(asset(Storage::url($noticia->imagen))); ?>); ">
                                </div>
                                <h4><?php echo e($noticia->categoria->nombre); ?></h4>
                                <h5><?php echo e($noticia->titulo); ?></h5>
    
                                <p class="nombre-noticia" ><?php echo e($noticia->descripcion); ?></p>
                            </div>
                            <button class="btn-noticias">LEER MÁS</button>
                        </div>

                        
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

<!--FIN SECCIÓN NOTICIAS-->


<!--INICIO SECCIÓN REPRESENTANTES-->

        <section class="section-home-representantes d-none d-md-block"> 
            <h3>REPRESENTANTES OFICIALES</h3>
            <div class="container">

                <?php $cantidadRepresentantes = count($representantes) ?>

                <div id="Cfooter" class="carousel carousel-representantes slide" data-bs-ride="carousel">
                    
                    <div class="carousel-indicators">

                    <?php $__currentLoopData = $representantes->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <button type="button" data-bs-target="#Cfooter" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel d-none d-md-block" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>

                    <div class="carousel-inner">
                            <?php $__currentLoopData = $representantes->chunk(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> ">
                                        <div class="row">

                                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($representante->show): ?>
                                                    
                                                            <div class="col img-representante"  style="background-image: url(<?php echo e(asset(Storage::url($representante->imagen))); ?>)">

                                                            </div>
                                                                                                    
                                                    <?php endif; ?>

                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\pyramiz3\resources\views/web/index.blade.php ENDPATH**/ ?>