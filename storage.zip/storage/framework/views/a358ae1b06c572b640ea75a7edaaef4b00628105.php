

<?php $__env->startSection('title','Categorías'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .list-group {
        border-radius: 0;
    }
    .list-group-item {
        position: relative;
    }
    .list-group-item > .btn-group {
        position: absolute;
        right: 0;
        top: 0;
        bottom: 0;
        border-radius: 0;
    }
    .list-group-item > .btn-group > .btn {
        border-radius: 0;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                <button type="button" class="btn btn-success" style="float:right;"><a style ="color:white;" href="<?php echo e(route('categories.create')); ?>"><i class="fas fa-plus" style ="color:white; margin-right:7px;" ></i>AÑADIR</a></button>
                <br>
                <br>
                <?php echo $__env->make('categories.categories-list', ['categories' => $categories, 'type' => 'list-group'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\pyramiz3\resources\views/categories/index.blade.php ENDPATH**/ ?>