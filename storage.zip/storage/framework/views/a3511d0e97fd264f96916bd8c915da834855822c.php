

<?php $__env->startSection('title','Añadir color '); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('productos.edit',$producto)); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al producto</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('coloresP.store', $producto)); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>



                            <div class="form-group col-md-4">
                                <label>Elige una color para el producto</label>
                                <select class="form-control" name="color_id">
                                    <option disabled>Elige una color...</option>
                                    <?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('color_id') == $color->id ? 'selected' : ''); ?> value="<?php echo e($color->id); ?>"> <?php echo e($color->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>
                            </div>
                            
                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>
                            <br>

                            <button type="submit" class="btn btn-primary mb-2">Enviar color</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/colores_p/create.blade.php ENDPATH**/ ?>