

<?php $__env->startSection('title','Preguntas Frecuentes'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-preguntas">
    <div class="container">

        
        <div class="accordion accordion-flush" id="accordionFlushExample">
            <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($pregunta->show): ?>
                    
                    <div class="accordion-item">
                        <h3 class="accordion-header" id="flush-heading<?php echo e($i); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($i); ?>" aria-expanded="false" aria-controls="flush-collapse<?php echo e($i); ?>">
                                <div class="icon-border"><div class="icon"></div></div> <?php echo e($pregunta->titulo); ?>

                            </button>
                        </h3>
                        <div id="flush-collapse<?php echo e($i); ?>" class="accordion-collapse collapse" aria-labelledby="flush-heading<?php echo e($i); ?>" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body"><?php echo $pregunta->parrafo; ?></div>
                        </div>
                    </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/web/preguntas_frecuentes.blade.php ENDPATH**/ ?>