

<?php $__env->startSection('title',strtoupper($categoria->nombre)); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-categoria" style="margin-bottom:65px">

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-3">
                <h5 style="font: normal normal bold 15px/60px Montserrat;letter-spacing: 0px;color: #000000; border-bottom: 2px solid #000000; height:45px;"> CATEGORÍAS</h5>
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', $item->id)); ?>" class="  <?php echo e($categoria_id == $item->id ? 'cat-activa' : 'cat-no-activa'); ?>  list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item2->show && $item->id == $item2->categoria_id ): ?>
                            <a  href="<?php echo e(route('web.productos.producto',$item2)); ?>" class="<?php echo e(false ? 'prod-activo' : 'prod-no-activo '); ?>list-group-item list-group-item-action list-trabajo" style=" padding-left:35px;" ><?php echo e($item2->nombre); ?></a>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-home-categorias col-9" style="margin-bottom: 24px"> 
                <div class="container">
                    <div class="row">

                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                <?php if($item->show): ?>
                                    <?php if(!$item->hay_stock): ?>
                                        <div class="col-12 col-md-4" >
                                            <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                                <div class="ribbon ribbon-top-left sin_stock"><span style="    background-color: #6c757d;">SIN STOCK</span></div>
                                            </div>
                                                
                                            <div class="text-box-categorias">
                                                <h4><?php echo e($item->nombre); ?></h4>
                                                <p class="precio" style="text-align: right;">$<?php echo e($item->tprecio); ?></p>
                                            </div> 
                                            </a>
                                            
                                        </div>
                                    <?php else: ?>
                                        <?php if($item->oferta): ?>
                                        <div class="col-12 col-md-4" >
                                            <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                                <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                            </div>
                                                
                                            <div class="text-box-categorias">
                                                <h4><?php echo e($item->nombre); ?></h4>
                                                <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($item->tprecio_anterior); ?></span>$<?php echo e($item->tprecio); ?></p>
                                            </div> 
                                            </a>
                                            
                                        </div>

                                        <?php else: ?>
                                            <div class="col-12 col-md-4" >
                                                <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); "></div>
                                                        
                                                    <div class="text-box-categorias">
                                                        <h4><?php echo e($item->nombre); ?></h4>
                                                        <p class="precio" style="text-align: right;">$<?php echo e($item->tprecio); ?></p>
                                                    </div> 
                                                </a>
                                            </div>   
                                        <?php endif; ?>
                                    <?php endif; ?>


                                    
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    </div>
                </div>
            </section>
        </div>
    </div>

</section>
<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/productos/categoria.blade.php ENDPATH**/ ?>