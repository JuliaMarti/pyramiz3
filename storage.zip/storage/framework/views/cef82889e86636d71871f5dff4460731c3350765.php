

<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-home-categorias" style="margin-bottom: 24px"> 
            
            
    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($categoria->show): ?>

                <div class="col-12 col-md-3 " style="margin-bottom:38px ">
                    <a href="<?php echo e(route('web.productos.categoria',$categoria)); ?>" style="text-decoration: none">
                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($categoria->imagen))); ?>); "></div>
                        
                    <div class="text-box-categorias">
                        <h4 ><?php echo e($categoria->nombre); ?></h4>
                    </div> 
                    </a>
                </div>

                    
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/productos/productos.blade.php ENDPATH**/ ?>