

<?php $__env->startSection('title','Clientes'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-clientes">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cliente->show): ?>

                    <div class="col-12 col-md-2">
                        <div class="img-border-grey  " style="background-image: url(<?php echo e(asset(Storage::url($cliente->imagen))); ?>); margin-bottom:26px;">
                        </div>
                    </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/clientes.blade.php ENDPATH**/ ?>