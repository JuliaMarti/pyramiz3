

<?php $__env->startSection('title','Configuración'); ?>

<?php $__env->startSection('content'); ?>


<div class="container cont-configuracion">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <?php $configuracion = $configuraciones->first() ?>
            
                        
                    <form action="<?php echo e(route('configuraciones.update',$configuracion)); ?>" enctype="multipart/form-data" method="POST">
                                
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('put'); ?>
                        
                         <div class="form-row">
                            <!--<div class="form-group col-md-6">
                                <label>Direccón</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-map-marker-alt"></i></span>
                                    </div>
                                    <input type="text" name="direccion" value="<?php echo e(old('direccion',$configuracion->direccion)); ?>" class="form-control"  placeholder="Direccón">
                                </div>
                            </div>   --> 
                            <div class="form-group col-md-6">
                                <label>Emial Info</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="far fa-envelope"></i></span>
                                    </div>
                                    <input type="email" name="email_info" value="<?php echo e(old('email_info',$configuracion->email_info)); ?>" class="form-control"  placeholder="Emial">
                                </div>
                            </div>  
                        </div>

                        <div class="form-row">
                            <!--<div class="form-group col-md-6">
                                <label>Celular</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-phone-alt"></i></span>
                                    </div>
                                    <input type="tel" name="tel_celular" value="<?php echo e(old('tel_celular',$configuracion->tel_celular)); ?>"  class="form-control"  placeholder="Celular">
                                </div>
                            </div>    -->
                            <div class="form-group col-md-6">
                                <label>WhatsApp</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fab fa-whatsapp"></i></span>
                                    </div>
                                    <input type="tel" name="wsp" value="<?php echo e(old('wsp',$configuracion->wsp)); ?>" class="form-control"  placeholder="WhatsApp">
                                </div>
                            </div>  
                        </div>
                        


                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label>Instagram</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fab fa-instagram"></i></span>
                                    </div>
                                    <input type="url" name="instagram" value="<?php echo e(old('instagram',$configuracion->instagram)); ?>"  class="form-control"  placeholder="Instagram">
                                </div>    
                            </div>
                        
                            <div class="form-group col-md-4">

                                <label>Facebook</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fab fa-facebook-f"></i></span>
                                    </div>
                                    <input type="url" name="facebook" value="<?php echo e(old('facebook',$configuracion->facebook)); ?>"  class="form-control"  placeholder="Facebook">
                                </div> 
                            </div>
                                                    
                            <div class="form-group col-md-4">
                                <label>Linkedin</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fab fa-youtube"></i></span>
                                    </div>
                                    <input type="url" name="linkedin" value="<?php echo e(old('linkedin',$configuracion->linkedin)); ?>"  class="form-control"  placeholder="Youtube">
                                </div> 
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary mb-2" >Actualizar Configuración</button>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\pyramiz\resources\views/configuraciones/index.blade.php ENDPATH**/ ?>