

<?php $__env->startSection('title','Preguntas'); ?>

<?php $__env->startSection('content'); ?>

<div class="container cont-preguntas">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                <button type="button" class="btn btn-success" style="float:right;"><a style ="color:white;" href="<?php echo e(route('preguntas.create')); ?>"><i class="fas fa-plus" style ="color:white; margin-right:7px;" ></i>AÑADIR</a></button>
                <br>
                <br>
                <div class="card" style="margin-top:15px;">

                    <div class="card-body" >

                                <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="display:flex; justify-content: space-between; width: 20%;">
                                        <p>Mostrar: <?php echo e($pregunta->show ? 'Si' : 'No'); ?></p>
                                        <p>Orden: <?php echo e($pregunta->orden); ?></p>
                                    </div>
                                    <p class="pregunta-titulo"><?php echo e($pregunta->titulo); ?></p>
                                    <p class="pregunta-parrafo"><?php echo e($pregunta->parrafo); ?></p>
                                    <div style="display:flex;">
                                        <button type="button" class="btn btn-primary" style="margin-right:5px;"><a style ="color:white;"href="<?php echo e(route('preguntas.edit',$pregunta)); ?>"><i class="far fa-edit"></i></a></button>
                                        <form action="<?php echo e(route('preguntas.destroy', $pregunta)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                
                                        </form>
                                    </div>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if(session('info')): ?>
                                <script>
                                    alert("<?php echo e(session('info')); ?>");
                                </script>
                                <?php endif; ?>
                    </div>
                </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz\resources\views/preguntas/index.blade.php ENDPATH**/ ?>