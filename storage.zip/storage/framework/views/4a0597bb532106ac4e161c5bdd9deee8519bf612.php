

<?php $__env->startSection('title','Carrito'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-carrito">
    <div class="container">
        <div class="row">
        
            <cart-list 
            ref="cart-list"
            />
            
        <div>
    </div>

</section>

<section style=" margin-top: 20px; margin-bottom: 36px;" >
    <div class="container">
        <checkout target="<?php echo e(route('web.envio_pedido')); ?>"
            ref="checkout"
            envio-local="<?php echo e($configpedido->envio_local); ?>"
            envio-comprador="<?php echo e($configpedido->envio_comprador); ?>"
            envio-caba="<?php echo e($configpedido->envio_caba); ?>"
            descuento-tarjeta="<?php echo e($configpedido->descuento_tarjeta); ?>"
            descuento-transferencia="<?php echo e($configpedido->descuento_transferencia); ?>"
            descuento-local="<?php echo e($configpedido->descuento_local); ?>"
        />
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/carrito.blade.php ENDPATH**/ ?>