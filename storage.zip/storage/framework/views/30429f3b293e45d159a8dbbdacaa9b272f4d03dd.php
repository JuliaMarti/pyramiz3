

<?php $__env->startSection('title', strtoupper($trabajo->nombre) ); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO PRODUCTO-->


<section class="section-categoria" >

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-2 d-none d-md-flex">
                <div class="list-group list-group-flush" style="width: 100%;">

                    <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show ): ?>
                        <a  href="<?php echo e(route('web.trabajos.trabajo',$item)); ?>" class="list-group-item list-group-item-action list-trabajo" style="<?php echo e($trabajo->id == $item->id ? 'background-color:#E8E8E8; color: #726D6E;' : 'color: #C7D52B;'); ?>" ><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-equipo col-10">
                <div class="container" style="padding-left:3px">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="">
                                <div class="img-trabajo" style="background-image: url(<?php echo e(asset(Storage::url($trabajo->imagen))); ?>); "></div>
                            </div>

                            <div class="container" style="padding-right:0; padding-left:0;">
                                <div class="row" style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2);">
                                    <?php $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="box-clase-mini col-3" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                    <div class="overlay"></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>
                        <div class="col-12 col-md-6" style="display: flex; flex-direction:column; justify-content:space-between">
                            <div>
                                <div class="tabla-trabajo">
                                    <?php echo $trabajo->tabla; ?>

                                </div>
                            
                            </div>

                        </div>
                    </div>
                    
                    <?php $__currentLoopData = $trabajo->secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($seccion->show): ?>
                            <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:40px;">
                                <div class="col-12" style="background-color: #C7D52B; padding-top:5px;"><h5><?php echo e($seccion->titulo); ?></h5></div>
                            </div>
                            <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:44px;">
                                <div class="col-12 descripcion"> <?php echo $seccion->texto; ?> </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($trabajo->show_imagen_grafico): ?>
                        <div class="row  d-none d-md-flex"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:40px; margin-bottom:89px; display:flex; justify-content:center;">
                            <div class="grafico col-8" style="background-image: url(<?php echo e(asset(Storage::url($trabajo->imagen_grafico))); ?>); ">
                        </div>
                        </div>
                    <?php endif; ?>

                
                    <div class="row  d-none d-md-flex"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); display:flex; justify-content:center;">
                        <?php if($trabajo->show_medidas): ?>   

                            <div class="col-4"> <div class="caracteristicas">   <h5>ESPESOR</h5> <div class="parf"><div><?php echo $trabajo->espesor; ?> </div></div>   </div>  </div>
                            <div class="col-4"> <div class="caracteristicas">   <h5>LARGO</h5> <div class="parf"><div><?php echo $trabajo->largo; ?> </div></div>   </div></div>
                            <div class="col-4"> <div class="caracteristicas">   <h5>ANCHO</h5> <div class="parf"><div><?php echo $trabajo->ancho; ?> </div></div>   </div></div>

                        <?php endif; ?>
                    </div>

                    <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); display:flex; justify-content:center;">
                        <h5 class="col-12" style="font: normal normal bold 15px/20px Roboto Condensed;letter-spacing: 0.7px;color: #726D6E; margin-top:47px; margin-bottom:27px;">PRODUCTOS RELACIONADOS</h5>
                        
                        <?php if($relacionado_1): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$relacionado_1)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_1->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_1->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if($relacionado_2): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$relacionado_2)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_2->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_2->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if($relacionado_3): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$relacionado_3)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_3->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_3->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
            </section>
        </div>
    </div>

</section>



<!--FIN PRODUCTO-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/trabajos/trabajo.blade.php ENDPATH**/ ?>