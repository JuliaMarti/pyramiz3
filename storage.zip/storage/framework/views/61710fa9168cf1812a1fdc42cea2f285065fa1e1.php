

<?php $__env->startSection('title','Equipo Nuevo'); ?>

<?php $__env->startSection('content'); ?>


<div class="container cont-equipos">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <a style ="color:grey;" href="<?php echo e(route('equipos.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de equipos</a>
            
            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('equipos.store')); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Nombre</label>
                                    <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control" placeholder="Nombre">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Modelo</label>
                                    <input type="text" name="modelo" value="<?php echo e(old('modelo')); ?>" class="form-control" placeholder="Modelo">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Elige una clase para el equipo</label>
                                    <select class="form-control" name="clase_id">
                                        <option disabled>Elige una clase...</option>
                                        <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('clase_id') == $clase->id ? 'selected' : ''); ?> value="<?php echo e($clase->id); ?>"> <?php echo e($clase->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Elige una altura de trabajo para el equipo</label>
                                    <select class="form-control" name="altura_id">
                                        <option disabled>Elige una altura de trabajo...</option>
                                        <?php $__currentLoopData = $alturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('altura_id') == $altura->id ? 'selected' : ''); ?> value="<?php echo e($altura->id); ?>"> <?php echo e($altura->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Elige un tipo de combustión para el equipo</label>
                                    <select class="form-control" name="combustion_id">
                                        <option disabled>Elige una un tipo de combustión...</option>
                                        <?php $__currentLoopData = $combustiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combustion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('combustion_id') == $combustion->id ? 'selected' : ''); ?> value="<?php echo e($combustion->id); ?>"> <?php echo e($combustion->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>


                            <div class="form-group">
                                <label>Imagen General</label>
                                <input type="file" accept="image/*" name="imagen_general" value="<?php echo e(old('imagen_general')); ?>" class="form-control-file" >
                            </div>

                            <div class="form-group">
                                <label>Imagen Detalle</label>
                                <input type="file" accept="image/*" name="imagen_detalle" value="<?php echo e(old('imagen_detalle')); ?>" class="form-control-file" >
                            </div>


                            <div class="form-group">
                                <label>Ficha técnica</label>
                                <input type="file" name="ficha_tecnica" value="<?php echo e(old('ficha_tecnica')); ?>" class="form-control-file" >
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('en_venta') == 1 ? 'checked' : ''); ?> name="en_venta" value="1">
                                <label class="form-check-label">En venta</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('en_alquiler') == 1 ? 'checked' : ''); ?> name="en_alquiler" value="1">
                                <label class="form-check-label">En alquiler</label>
                            </div>

                            <div class="form-group ">
                                <label>Información detallada</label>
                                <textarea class="form-control summernote" name="tabla"  rows="3"><?php echo e(old('tabla')); ?></textarea>
                            </div>

                            

                            <button type="submit" class="btn btn-primary mb-2">Enviar Equipo</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/equipos/create.blade.php ENDPATH**/ ?>