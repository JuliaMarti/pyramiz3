

<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startSection('content'); ?>
<div class="container cont-descargas">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                <button type="button" class="btn btn-success" style="float:right;"><a style ="color:white;" href="<?php echo e(route('productos.create')); ?>"><i class="fas fa-plus" style ="color:white; margin-right:7px;" ></i>AÑADIR</a></button>
                <br>

                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <br>
                    <div class="card" style="margin-top:15px;">
                
                        <div class="card-body p-0" >

                            <div style="padding-top:15px;">
                                <div class="container">
                                    <div class="row">
                                        <h4 class="col-4" style="color:#03224e;font-size: 24px; margin-bottom: 15px; margin-left:5px;"><?php echo e($producto->nombre); ?></h4>
                                        <div class="col-2"><img src="<?php echo e(asset(Storage::url($producto->imagen))); ?>" style="height:60px;max-width: 300px"></td></div>
                                        <div class="col-2"> <td><?php echo e($producto->show ? 'Mostrar' : 'No mostrar'); ?></td> </div>
                                        <div class="col-3" style="display:flex; "> 
                                            <button type="button" class="btn btn-success" style="margin-right:5px; margin-bottom:10px "> <a style ="color:white; " href="<?php echo e(route('seccionesP.create',$producto)); ?>"> <span>AÑADIR SECCIÓN</span></a></button>
                                            <button type="button" class="btn btn-success" style="margin-right:5px; margin-bottom:10px "> <a style ="color:white; " href="<?php echo e(route('galeriasP.create',$producto)); ?>"> <span>AÑADIR FOTO</span></a></button>
                                            <button type="button" class="btn btn-primary" style="margin-right:5px; margin-bottom:10px"><a style ="color:white; "href="<?php echo e(route('productos.edit',$producto)); ?>"><i class="far fa-edit"></i></a></button>
                                            <form action="<?php echo e(route('productos.destroy', $producto)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                    
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                                                            
                            <table class="table" style="width: 100%">
                                <thead style="color:#03224e"> 
                                    <tr>
                                        <th scope="col">Título</th>
                                        <th scope="col">Mostrar</th>
                                        <th scope="col">Orden</th>
                                        <th scope="col">Acciones</th>
                                    </tr>
                                </thead>

                                <tbody>  
                                    
                                    <?php if($producto->secciones): ?>
                                        
                                    <?php $__currentLoopData = $producto->secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            

                                                <tr>
                                                    <td><?php echo e($seccion->titulo); ?></td>
                                                    <td><?php echo e($seccion->show ? 'Si' : 'No'); ?></td>
                                                    <td><?php echo e($seccion->orden); ?></td>
                                                    <td style="display:flex;">
                                                        <button type="button" class="btn btn-primary" style="margin-right:5px;"><a style ="color:white;"href="<?php echo e(route('seccionesP.edit',$seccion)); ?>"><i class="far fa-edit"></i></a></button>
                                                        <form action="<?php echo e(route('seccionesP.destroy', $seccion)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                                
                                                        </form>
                                                    </td>
                                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>
                                    <tr>
                                        <th scope="col">Imagen</th>
                                        <th scope="col">Mostrar</th>
                                        <th scope="col">Orden</th>
                                        <th scope="col">Acciones</th>
                                    </tr>

                                    <?php if($producto->galerias): ?>
                                        
                                    <?php $__currentLoopData = $producto->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            

                                                <tr>
                                                    <td > <img src="<?php echo e(asset(Storage::url($galeria->imagen))); ?>" style="height:60px;max-width: 300px"></td>
                                                    <td><?php echo e($galeria->show ? 'Si' : 'No'); ?></td>
                                                    <td><?php echo e($galeria->orden); ?></td>
                                                    <td style="display:flex;">
                                                        <button type="button" class="btn btn-primary" style="margin-right:5px;"><a style ="color:white;"href="<?php echo e(route('galeriasP.edit',$galeria)); ?>"><i class="far fa-edit"></i></a></button>
                                                        <form action="<?php echo e(route('galeriasP.destroy', $galeria)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                                
                                                        </form>
                                                    </td>
                                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php endif; ?>


                                    
                                </tbody>
                            </table>    

                            <hr style="font-weight: bold; color:black">

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/show_productos/index.blade.php ENDPATH**/ ?>