

<?php $__env->startSection('title', strtoupper($producto->nombre) ); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO PRODUCTO-->


<section class="section-equipo section-categoria" >

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-3">
                
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria',[$item->id,$familia])); ?>" class="  <?php echo e($categoria_id == $item->id ? 'cat-activa' : 'cat-no-activa'); ?>  list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item2->show && $item->id == $item2->categoria_id ): ?>
                            <a  href="<?php echo e(route('web.productos.producto',[$item2,$familia])); ?>" class="<?php echo e($producto->id == $item2->id  ? 'prod-activo' : 'prod-no-activo '); ?> list-group-item list-group-item-action list-trabajo" style=" padding-left:35px;" ><?php echo e($item2->nombre); ?></a>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-home-categorias col-9"> 
                <div class="container-fluid" style="padding-left:3px">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            
                                

                            <galeria-producto oferta="<?php echo e($producto->oferta); ?>"
                                ref="galeria"
                            /> 
                            

                            

                        </div>
                        <div class="col-12 col-md-6" style="display: flex; flex-direction:column; justify-content:space-between;">
                            <div>
                                <div class="tabla-trabajo" style="font: normal normal bold 25px/29px Montserrat;color: #000000;">
                                    <?php echo e($producto->nombre); ?>

                                </div>
                                
                                <p class="precio" style=" font: normal normal bold 31px/42px Montserrat;">
                                    <?php if($producto->oferta && $producto->hay_stock): ?>
                                    <span class="precio-oferta" style="font: normal normal medium 18px/42px Montserrat; margin-right:19px;">$<?php echo e($producto->tprecio_anterior); ?></span>
                                    <?php endif; ?>
                                    
                                    $<?php echo e($producto->tprecio); ?>


                                </p>

                                <div class="descripcion" style="margin-bottom:25px;"> <?php echo $producto->descripcion; ?> </div>

                                <div>
                                
                                        
                                        
                                            <add-to-cart unit="<?php echo e($producto->unidad_de_venta ?? 1); ?>"
                                                price="<?php echo e($producto->precio); ?>"
                                                nombre="<?php echo e($producto->nombre); ?>"
                                                imagen="<?php echo e($producto->imagen_url); ?>"
                                                id="<?php echo e($producto->id); ?>"
                                                ref="me"
                                            /> 
                                        
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                
                    <div class="row" style="margin-bottom:35px;">
                        <h5 style="font: normal normal 600 17px/52px Montserrat;color: #2B1C17; border-bottom: 1px solid #BFBFBF; margin-left: calc(var(--bs-gutter-x)/ 2);">Especificaciones</h5>
                        <div class="especificaciones"><?php echo $producto->tabla; ?></div>
                    </div>

                    

                </div>
            </section>
        </div>
    </div>

</section>



<!--FIN PRODUCTO-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?> 
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    window.colores = <?php echo $colores; ?>

    window.galerias = <?php echo $producto->galerias; ?>

    window.diametros = <?php echo $producto->diametros; ?>


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/web/productos/producto.blade.php ENDPATH**/ ?>