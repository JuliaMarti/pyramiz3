<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $__env->yieldContent('title'); ?></title>
    

    <!-- Bootstrap -->
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,300;0,400;1,400&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    
    
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>



    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    </head>

    <body>
<!--INICIO HEADER-->


        <header>
                <div class=" header-top  ">
                    <div class="container" style="display: flex; justify-content: space-between;">
                            <div class="fondo header-top-box d-none d-md-flex">
                                <div class="item-header " style="margin-right:26px">
                                    <i class="fas fa-phone-alt" style="margin-right:12px; font-size:12px;"></i>
                                <?php echo $configuracion->tel; ?>

                                </div>   
                                <div class="item-header" >
                                    <i class="fab fa-whatsapp" style="margin-right:9px;"></i> 
                                    <a href="https://api.whatsapp.com/send?phone=<?php echo e($configuracion->wsp); ?>" <?php echo e($configuracion->wsp ? 'target=”_blank”' : ''); ?>”><?php echo e($configuracion->wsp); ?></a>
                                </div>
                            </div>

                            <div>
                                <div class="header-top-box" >
                                    <div class="header-top-item presupuesto d-none d-md-flex" style="<?php echo e($breadcrumb[0]['title'] == 'presupuesto' ? 'background-color:#726D6E; color: #C7D52B;' : 'background-color:#0E8B2F;'); ?> ">
                                        <a href="<?php echo e(route('web.solicitud_de_presupuesto')); ?>">SOLICITUD DE PRESUPUESTO</a>         
                                    </div> 
                                    
                                    
                                </div>
                            </div>
                    </div>
                </div>

                <nav>
                    <div class="container" style="display: flex; justify-content: space-between;">
                        
                            <a href="<?php echo e(route('web.home')); ?>" class="col-8 col-md-2">
                                <img src="<?php echo e(asset(Storage::url($home->logo))); ?>"  alt="Pyramiz" style="width: 100%;">
                            </a>

                            <button class="nav-btn d-flex d-md-none" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fas fa-bars"></i></button>
                    
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.home')); ?>">HOME</a>
                                            </li>
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'empresa' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.empresa')); ?>">QUIENES SOMOS</a>
                                            </li>
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.productos.productos')); ?>">PRODUCTOS</a>
                                            </li>
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>">SERVICIOS</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'trabajos' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.trabajos.trabajos')); ?>">TRABAJOS REALIZADOS</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'clientes' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.clientes')); ?>">CLIENTES</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'preguntas_frecuentes' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.preguntas_frecuentes')); ?>">PREGUNTAS FRECUENTES</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'presupuesto' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.solicitud_de_presupuesto')); ?>">PRESUPUESTO</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>">CONTACTO</a>
                                            </li>                                        
                                        </div>
                                        <div class="modal-footer">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <ul class="nav d-none d-md-flex">
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.home')); ?>">HOME</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'empresa' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.empresa')); ?>">QUIENES SOMOS</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.productos.productos')); ?>">PRODUCTOS</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'servicios' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.servicios')); ?>">SERVICIOS</a>
                                </li> 
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'trabajos realizados' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.trabajos.trabajos')); ?>">TRABAJOS REALIZADOS</a>
                                </li> 
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'clientes' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.clientes')); ?>">CLIENTES</a>
                                </li> 
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'preguntas frecuentes' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.preguntas_frecuentes')); ?>">PREGUNTAS FRECUENTES</a>
                                </li> 
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>" > CONTACTO</a>
                                </li>
                            </ul>
                    </div>
                </nav>  


                <?php if($breadcrumb[0]['title'] !='home' && $breadcrumb[0]['title'] !='empresa' && $breadcrumb[0]['title'] !='contacto' ): ?>
                <div class="header-bottom">
                    <div class="container header-bottom-cont" >
                        <div class="header-breadcrumb">
                            <a href="<?php echo e(route('web.home')); ?>"><!--<i class="fas fa-home">--></i></a>
                            <?php $__currentLoopData = $breadcrumb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                <a class="<?php echo e($key == (count($breadcrumb)-1) ? 'active-link' : ''); ?> after" href="<?php echo e(route($bread['link'],$bread['cat'] ? $bread['cat'] : '' )); ?>"><?php echo e($bread['title']); ?></a>
    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </header>


<!--FIN HEADER-->
    
        <main>

            <?php echo $__env->yieldContent('content'); ?>

        </main>

<!--INICIO FOOTER-->        

        <footer>

            <div class="footer-top">
                <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a style="margin-right:3px;margin-left:3px;" href="<?php echo e($red->url); ?>" <?php echo e($red->url ? 'target=”_blank”' : ''); ?>  ><div class="icon-border"><?php echo $red->icono; ?></div></a>                             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div class="footer-info d-none d-md-flex ">
                <div class="container footer-box">
                    <div class="row">

                        <div class="col-3" style="display: flex;" >
                            <img src="<?php echo e(asset(Storage::url($home->logo_footer))); ?>">
                        </div>
                        <div class="col"></div>
                        <div class="col-2 d-none d-sm-none d-md-block" >
                            <h5>SECCIONES</h5>
                            <p><a href="<?php echo e(route('web.home')); ?>" >HOME</a></p>
                            <p><a href="<?php echo e(route('web.empresa')); ?>" >QUIENES SOMOS</a></p>
                            <p><a href="<?php echo e(route('web.productos.productos')); ?>" >TRABAJOS REALIZADOS</a></p> 
                            <p><a href="<?php echo e(route('web.contacto')); ?>" >CLIENTES</a></p>
                        </div>


                        <div class="col-2 d-none d-sm-none d-md-block" >
                            <h5 style="color:transparent">SECCIONES</h5>
                            <p><a href="<?php echo e(route('web.home')); ?>" >PREGUNTAS FRECUENTES</a></p>
                            <p><a href="<?php echo e(route('web.empresa')); ?>" >SOLICITUD DE PRESUPUESTO</a></p>
                            <p><a href="<?php echo e(route('web.productos.productos')); ?>" >CONTACTO</a></p> 
                        </div>
                        <div class="col-1"></div>
                        <div class="col-3 p-0 d-none d-sm-none d-md-block">
                            <h5 style="">CONTÁCTANOS</h5>
                    
                            <div class="item-footer">
                                <i class="fas fa-map-marker-alt"></i>
                                <p><?php echo e($configuracion->direccion); ?></p>
                            </div>
                            
                            <div class="item-footer" style="">
                                <i class="fas fa-envelope" ></i> 
                                <p><a href="mailto:<?php echo e($configuracion->email); ?>" target=”_blank”><?php echo e($configuracion->email); ?></a></p>
                            </div>
                            <div class="item-footer" style="">
                                <i class="fas fa-phone-alt"></i>
                                <p><?php echo $configuracion->tel; ?></p>
                            </div>   
                            <div class="item-footer" >
                                <i class="fab fa-whatsapp"></i>
                                <p><a href="https://api.whatsapp.com/send?phone=<?php echo e($configuracion->wsp); ?>" <?php echo e($configuracion->wsp ? 'target=”_blank”' : ''); ?>><?php echo e($configuracion->wsp); ?></a></p>
                            </div> 
                        </div>

                    
                </div>             
            </div>
           </div>
        </footer>

<!--FIN FOOTER-->    
<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>



</body>
</html>
<?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>