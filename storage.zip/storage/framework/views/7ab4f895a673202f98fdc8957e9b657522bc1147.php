

<?php $__env->startSection('title','Producto Nuevo'); ?>

<?php $__env->startSection('content'); ?>


<div class="container cont-products">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <a style ="color:grey;" href="<?php echo e(route('products.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de productos</a>
            
            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Nombre</label>
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="Nombre">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Elige una categoría para el producto</label>
                                    <select class="form-control" name="categoria_id">
                                        <option>Elige una categoría...</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('categoria_id') == $categoria->id ? 'selected' : ''); ?> value="<?php echo e($categoria->id); ?>"> <?php echo e($categoria->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Descripción</label>
                                <textarea class="form-control" name="description"  rows="3"><?php echo e(old('description')); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label>Imagen Principal</label>
                                <input type="file" accept="image/*" name="imagen_principal" value="<?php echo e(old('imagen_principal')); ?>" class="form-control-file" >
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('destacado') == 1 ? 'checked' : ''); ?> name="destacado" value="1">
                                <label class="form-check-label">Destacado</label>
                            </div>

                            <h4>Medidas</h4>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Ancho máximo</label>
                                    <input type="number" name="ancho_maximo" value="<?php echo e(old('ancho_maximo')); ?>" class="form-control" placeholder="Ancho máximo">
                                </div>

                                <div class="form-group col-md-6">
                                    <label>Largo máximo</label>
                                    <input type="number" name="largo_maximo" value="<?php echo e(old('largo_maximo')); ?>" class="form-control" placeholder="Largo máximo">
                                </div>
                            </div>

                            <h4>Equipamiento</h4>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('plasma_HD') == 1 ? 'checked' : ''); ?> name="plasma_HD" value="1">
                                <label class="form-check-label"> Plasma HD</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('plasma_O2') == 1 ? 'checked' : ''); ?> name="plasma_O2" value="1">
                                <label class="form-check-label">Plasma O2</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('plasma_aire') == 1 ? 'checked' : ''); ?> name="plasma_aire" value="1">
                                <label class="form-check-label">Plasma Aire</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('oxicorte') == 1 ? 'checked' : ''); ?> name="oxicorte" value="1">
                                <label class="form-check-label">Oxicorte</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('marcador_plasma') == 1 ? 'checked' : ''); ?> name="marcador_plasma" value="1">
                                <label class="form-check-label">Marcador Plasma</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('marcador_neumatico') == 1 ? 'checked' : ''); ?> name="marcador_neumatico" value="1">
                                <label class="form-check-label">Marcador Neumático</label>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Control de altura Plasma</label>
                                    <input type="text" name="control_altura_plasma" value="<?php echo e(old('control_altura_plasma')); ?>" class="form-control" placeholder="Control de altura Plasma">
                                </div>

                                <div class="form-group col-md-6">
                                    <label> Control de altura Oxicorte</label>
                                    <input type="text" name="control_altura_oxicorte" value="<?php echo e(old('control_altura_oxicorte')); ?>" class="form-control" placeholder="Control de altura Oxicorte">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Cabezal biselador plasma</label>
                                    <input type="text" name="cabezal_biselador_plasma" value="<?php echo e(old('cabezal_biselador_plasma')); ?>" class="form-control" placeholder="Cabezal biselador plasma">
                                </div>

                                <div class="form-group col-md-6">
                                    <label> Cabezal bicelador oxicorte</label>
                                    <input type="text" name="cabezal_biselador_oxicorte" value="<?php echo e(old('cabezal_biselador_oxicorte')); ?>" class="form-control" placeholder="Cabezal bicelador oxicorte">
                                </div>
                            </div>

                            <h4> Componentes </h4>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('vias_desplazamiento') == 1 ? 'checked' : ''); ?> name="vias_desplazamiento" value="1">
                                <label class="form-check-label"> Vías de desplazamiento</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('bases_apoyo') == 1 ? 'checked' : ''); ?> name="bases_apoyo" value="1">
                                <label class="form-check-label">Bases de apoyo</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('cremalleras_presicion') == 1 ? 'checked' : ''); ?> name="cremalleras_presicion" value="1">
                                <label class="form-check-label">Cremalleras de presición</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('servo_motores') == 1 ? 'checked' : ''); ?> name="servo_motores" value="1">
                                <label class="form-check-label">Servo Motores</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('cajas_reductoras') == 1 ? 'checked' : ''); ?> name="cajas_reductoras" value="1">
                                <label class="form-check-label">Cajas reductoras</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('CNC') == 1 ? 'checked' : ''); ?> name="CNC" value="1">
                                <label class="form-check-label">CNC</label>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label> Panel Operador</label>
                                    <input type="text" name="panel_operador" value="<?php echo e(old('panel_operador')); ?>" class="form-control" placeholder="Panel Operador">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Pantalla Industrial</label>
                                    <input type="text" name="pantalla_industrial" value="<?php echo e(old('pantalla_industrial')); ?>" class="form-control" placeholder="Pantalla Industrial">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Límites de carrera</label>
                                    <input type="text" name="limites_carrera" value="<?php echo e(old('limites_carrera')); ?>" class="form-control" placeholder="Límites de carrera">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Características principales (izquierda)</label>
                                <textarea class="form-control summernote" name="lista_izquierda"  rows="3"><?php echo e(old('lista_izquierda')); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Características principales (derecha)</label>
                                <textarea class="form-control summernote" name="lista_derecha"  rows="3"><?php echo e(old('lista_derecha')); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label>Características de display</label>
                                <textarea class="form-control summernote" name="lista_display" rows="3"><?php echo e(old('lista_display')); ?></textarea>
                                <label>Imagen display</label>
                                <input type="file" accept="image/*" name="imagen_display" value="<?php echo e(old('imagen_display')); ?>" class="form-control-file" >
                            </div>
                            <div class="form-group">
                                <label>Características de corte</label>
                                <textarea class="form-control summernote"  name="lista_corte" rows="3"><?php echo e(old('lista_corte')); ?></textarea>
                                <label>Imagen corte</label>
                                <input type="file" accept="image/*" name="imagen_corte" value="<?php echo e(old('imagen_corte')); ?>" class="form-control-file" >
                            </div>

                            <div class="form-group">
                                <label>Imagen de características técnicas</label>
                                <input type="file" accept="image/*" name="imagen_caract_tecnicas" value="<?php echo e(old('imagen_caract_tecnicas')); ?>" class="form-control-file" >
                            </div>

                            <h4>Dimensiones útiles de corte</h4>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Ancho</label>
                                    <input type="number" name="dimension_util_corte_ancho" value="<?php echo e(old('dimension_util_corte_ancho')); ?>" class="form-control" placeholder="Ancho">
                                </div>

                                <div class="form-group col-md-6">
                                    <label>Alto</label>
                                    <input type="number" name="dimension_util_corte_alto" value="<?php echo e(old('dimension_util_corte_alto')); ?>" class="form-control" placeholder="Alto">
                                </div>
                            </div>

                            <h4>Dimensiones generales</h4>
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Ancho</label>
                                    <input type="number" name="ancho" value="<?php echo e(old('ancho')); ?>" class="form-control" placeholder="Ancho">
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Alto</label>
                                    <input type="number" name="alto" value="<?php echo e(old('alto')); ?>" class="form-control" placeholder="Alto">
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Profundidad</label>
                                    <input type="number" name="profundidad" value="<?php echo e(old('profundidad')); ?>" class="form-control" placeholder="Profundidad">
                                </div>
                            </div>

                            <h4>Especificaciones ténicas </h4>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label> Sistemas de corte</label>
                                    <input type="text" name="sistemas_de_corte" value="<?php echo e(old('sistemas_de_corte')); ?>" class="form-control" placeholder="Sistemas de corte">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Velocidad máx. desplazamiento</label>
                                    <input type="number" name="velocidad_max_desplazamiento" value="<?php echo e(old('velocidad_max_desplazamiento')); ?>" class="form-control" placeholder="Velocidad máx. desplazamiento">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Velocidad máx. de corte</label>
                                    <input type="number" name="velocidad_max_corte" value="<?php echo e(old('velocidad_max_corte')); ?>" class="form-control" placeholder="Velocidad máx. de corte">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label> Transmisiones</label>
                                    <input type="text" name="transmisiones" value="<?php echo e(old('transmisiones')); ?>" class="form-control" placeholder="Transmisiones">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Sistema de guiado</label>
                                    <input type="text" name="sistema_de_guiado" value="<?php echo e(old('sistema_de_guiado')); ?>" class="form-control" placeholder="Sistema de guiado">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Motorización</label>
                                    <input type="text" name="motorizacion" value="<?php echo e(old('motorizacion')); ?>" class="form-control" placeholder="Motorización">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label> Estructura mecánica</label>
                                    <input type="text" name="estructura_mecanica" value="<?php echo e(old('estructura_mecanica')); ?>" class="form-control" placeholder="Estructura mecánica">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Control de altura Plasma</label>
                                    <input type="text" name="control_altura_plasma_2" value="<?php echo e(old('control_altura_plasma_2')); ?>" class="form-control" placeholder="Control de altura Plasma">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Sistema de Detección de Chapa</label>
                                    <input type="text" name="sistema_deteccion_chapa" value="<?php echo e(old('sistema_deteccion_chapa')); ?>" class="form-control" placeholder="Sistema de Detección de Chapa">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label> Software</label>
                                    <input type="text" name="software_CAD_CAM" value="<?php echo e(old('software_CAD_CAM')); ?>" class="form-control" placeholder="Software">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Control</label>
                                    <input type="text" name="control" value="<?php echo e(old('control')); ?>" class="form-control" placeholder="Control">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Display</label>
                                    <input type="text" name="display" value="<?php echo e(old('display')); ?>" class="form-control" placeholder="Display">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label> Comunicación</label>
                                    <input type="text" name="comunicacion" value="<?php echo e(old('comunicacion')); ?>" class="form-control" placeholder="Comunicación">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Alimentacion eléctrica</label>
                                    <input type="text" name="alimentacion_electrica" value="<?php echo e(old('alimentacion_electrica')); ?>" class="form-control" placeholder="Alimentacion eléctrica">
                                </div>

                                <div class="form-group col-md-4">
                                    <label> Peso</label>
                                    <input type="number" name="peso" value="<?php echo e(old('peso')); ?>" class="form-control" placeholder="Peso">
                                </div>
                            </div>

                            <button type="submite" class="btn btn-primary mb-2">Enviar Producto</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/products/create.blade.php ENDPATH**/ ?>