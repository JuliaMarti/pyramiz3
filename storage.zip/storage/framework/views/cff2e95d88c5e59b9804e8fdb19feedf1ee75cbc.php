

<?php $__env->startSection('title','Editar dirección'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('direcciones.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de categorías de noticias</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('direcciones.update',$direccion)); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden',$direccion->orden)); ?>" class="form-control" placeholder="Orden">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Nombre</label>
                                    <input type="text" name="nombre" value="<?php echo e(old('nombre',$direccion->nombre)); ?>" class="form-control" placeholder="Nombre">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Email</label>
                                    <input type="email" name="email" value="<?php echo e(old('email',$direccion->email)); ?>" class="form-control" placeholder="Email">
                                </div>
                                <div class="form-group col-md-8">
                                    <label>Dirección</label>
                                    <input type="text" name="direccion" value="<?php echo e(old('direccion',$direccion->direccion)); ?>" class="form-control" placeholder="Dirección">
                                </div>
                            </div>
                           
                            <div class="form-group">
                                <label>Teléfonos</label>
                                <textarea class="form-control summernote" name="telefonos"  rows="3"><?php echo e(old('telefonos',$direccion->telefonos)); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label>Iframe del mapa</label>
                                <textarea class="form-control" name="map"  rows="3"><?php echo e(old('map',$direccion->map)); ?></textarea>
                            </div>
                            

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show',$direccion->show) == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('footer',$direccion->footer) == 1 ? 'checked' : ''); ?> name="footer" value="1">
                                <label class="form-check-label">Mostrar en el footer (no más de 2)</label>
                            </div>
                            <br>

                            <button type="submit" class="btn btn-primary mb-2">Actualizar dirección</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz\resources\views/direcciones/edit.blade.php ENDPATH**/ ?>