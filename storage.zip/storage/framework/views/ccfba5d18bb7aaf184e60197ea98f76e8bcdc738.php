

<?php $__env->startSection('title','Empresa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container cont-empresa">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php $empresa = $empresas->first() ?>


                    <form action="<?php echo e(route('empresas.update',$empresa)); ?>" enctype="multipart/form-data" method="POST">
                                
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('put'); ?>
                        

                        <div class="form-group">
                            <label><h4 class="primer-h4">Párrafo</h4></label>
                            <hr>
                            <textarea class="form-control summernote" name="parrafo"  rows="4"><?php echo e(old('parrafo',$empresa->parrafo)); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label><h4 class="primer-h4">Imagen</h4></label>
                            <hr>
                            <div class="form-group">
                                <label>Imagen</label>
                                <input type="file" accept="image/*" name="imagen" value="<?php echo e(old('imagen',$empresa->imagen)); ?>" class="form-control-file" >
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary mb-2" >Actualizar Empresa</button>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/empresas/index.blade.php ENDPATH**/ ?>