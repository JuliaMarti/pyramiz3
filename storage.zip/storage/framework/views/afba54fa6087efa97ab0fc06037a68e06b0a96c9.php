

<?php $__env->startSection('title','Pyramiz'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->
<div id="carouselExampleIndicators" class="carousel carousel-inicio slide" data-bs-ride="carousel">
            
            <div class="carousel-indicators">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel d-none d-md-block" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="carousel-inner">
                    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " style="background-image: url(<?php echo e(asset(Storage::url($imagen->imagen))); ?>)">
                                <div class="carousel-overlay"></div>
                                <div class="carousel-caption d-none d-md-block">
                                    <h1><?php echo $imagen->parrafo_1; ?></h1>
                                    <p><?php echo $imagen->parrafo_2; ?></p>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>






    <!--<div id="carouselExampleIndicators" class="carousel carousel-inicio slide" data-bs-ride="carousel">
            
            <div class="carousel-indicators">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="carousel-inner">
                    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " style="display:flex; ">

                                <div class="carousel-caption d-none d-md-block">
                                    <h2><?php echo $imagen->titulo; ?></h2>
                                    <h3><?php echo $imagen->subtitulo; ?></h3>
                                    <p><?php echo $imagen->texto; ?></p>
                                </div>
                                <div>
                                    <img style="width:100px" src="<?php echo e(asset(Storage::url($imagen->imagen))); ?>" alt="First slide">
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div> 

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>-->
<!--FIN CAROUSEL-INICIO-->

        <?php if($home->seccion_1_show): ?>
            <div class="container home-sections">
                <div class="row">
                    <div class="col-12 col-md-6 home-sec-1">
                        <h2><?php echo $home->seccion_1_titulo; ?></h2>
                        <p><?php echo e($home->seccion_1_parrafo); ?></p>
                        <hr>
                        <div class="heaer-top-item wsp">
                            <a href="https://api.whatsapp.com/send?phone=<?php echo e($configuracion->wsp); ?>" target=”_blank”><i class="fab fa-whatsapp"></i>+<?php echo e($configuracion->wsp); ?></a>
                            <a href="mailto:<?php echo e($configuracion->email); ?>" target=”_blank”><i class="far fa-envelope"></i> <?php echo e($configuracion->email_info); ?></a>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 home-sec-2">
                        <img style="width:22%; padding-bottom:100%;" src="<?php echo e(asset('img/home/mercado_shops.png')); ?>" >
                        <h2><?php echo $home->seccion_2_titulo; ?></h2>
                        <p><?php echo e($home->seccion_2_parrafo); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?> 



<!--INICIO SECCIÓN SERVICIOS-->


<?php $noticiaServicio = $noticias->first() ?>
        <section class="section-home-servicios"> 
            <h3>SERVICIOS</h3>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6">
                            <div class="img-border-servicios" style="background-image: url(<?php echo e(asset(Storage::url($noticiaServicio->imagen))); ?>); ">
                                
                                <div class="text-box-servicios">
                                    <h4><?php echo e($noticiaServicio->titulo); ?></h4>
                                    <h5><?php echo e($noticiaServicio->subtitulo); ?></h5>
                                </div> 
                            </div>


                            <p class="nombre-noticia" ><?php echo e($noticiaServicio->descripcion); ?></p>
                    </div>

                    <div class="col-6">

                    </div>

                    <div class="col-6">

                    </div>

                    <div class="col-6">

                    </div>
                   
                </div>
            </div>
        </section>

<!--FIN SECCIÓN SERVICIOS-->



<!--INICIO SECCIÓN NOTICIAS-->

        <section class="section-home-noticias"> 
            <h3>ÚLTIMAS NOTICIAS</h3>
            <div class="container">
                <div class="row">

                     <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($noticia->home): ?>
                        <div class="col-12 col-md-6"  >
                            <div class="img-border-noticias" style="background-image: url(<?php echo e(asset(Storage::url($noticia->imagen))); ?>); ">
                            </div>
                            <h4><?php echo e($noticia->titulo); ?></h4>
                            <h5><?php echo e($noticia->subtitulo); ?></h5>

                            <p class="nombre-noticia" ><?php echo e($noticia->descripcion); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

<!--FIN SECCIÓN NOTICIAS-->


<!--INICIO SECCIÓN REPRESENTANTES-->

        <section class="section-home-representantes"> 
            <h3>REPRESENTANTES OFICIALES</h3>
            <div class="container">

                <?php $cantidadRepresentantes = count($representantes) ?>

                <div id="carouselExampleIndicators" class="carousel carousel-representantes slide" data-bs-ride="carousel">
                    
                    <div class="carousel-indicators">
                    <?php $__currentLoopData = $representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel d-none d-md-block" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="carousel-inner">
                            <?php $__currentLoopData = $representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> ">
                                        <div class="row">
                                        
                                                <?php $__currentLoopData = $representantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($representante->show): ?>
                                                    
                                                            <div class="col img-representante"  style="background-image: url(<?php echo e(asset(Storage::url($representante->imagen))); ?>)">

                                                            </div>
                                                        

                                                                                                              
                                                    <?php endif; ?>

                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>






<!--FIN SECCIÓN REPRESENTANTES-->





<!--INICIO SECCIÓN EQUIPOS DESTACADOS-->
        
<!--FIN SECCIÓN EQUIPOS DESTACADOS-->        


<!--INICIO SECCIÓN LIBELLUA-->
        
<!--FIN SECCIÓN LIBELLUA-->


<!--INICIO SECCIÓN NUESTRA MISIÓN-->
        
        

<!--FIN SECCIÓN NUESTRA MISIÓN-->

        


<!--INICIO SECCIÓN KRRASS-->
        

<!--FIN SECCIÓN KRRASS-->

<!--INICIO SECCIÓN NUESTROS PRODUCTOS-->        
        
<!--FIN SECCIÓN NUESTROS PRODUCTOS-->        



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\pyramiz\resources\views/web/index.blade.php ENDPATH**/ ?>