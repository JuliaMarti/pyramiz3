

<?php $__env->startSection('title','Servicios'); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO SERVICIOS-->


            <section class="section-servicios ">
                <div class="container">
                    <div class="row">

                        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-12 col-md-4" style="display: flex; justify-content: center; flex-direction:column; align-items:center; margin-bottom:25px;">
                            <div class="imagen" style=" background-image: url( <?php echo e(asset(Storage::url($servicio->imagen))); ?> ); "> <div class="overlay"></div></div>
                            <div class="imagen-text"  style="display: flex; justify-content: center; flex-direction:column; align-items:center">
                                
                                <div class="text-servicio"  >
                                    <h4><?php echo e($servicio->titulo); ?></h4>
                                    
                                    <p><?php echo e($servicio->descripcion); ?></p>
                                </div>

                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>


        

            
<!--FIN POST VENTA-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/servicios.blade.php ENDPATH**/ ?>