

<?php $__env->startSection('title','Configuración'); ?>

<?php $__env->startSection('content'); ?>


<div class="container cont-configuracion">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <?php $configuracion = $configuraciones->first() ?>
            
                        
                    <form action="<?php echo e(route('configuraciones.update',$configuracion)); ?>" enctype="multipart/form-data" method="POST">
                                
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('put'); ?>
                        
                         <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Direccón</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-map-marker-alt"></i></span>
                                    </div>
                                    <input type="text" name="direccion" value="<?php echo e(old('direccion',$configuracion->direccion)); ?>" class="form-control"  placeholder="Direccón">
                                </div>
                            </div> 
                            <div class="form-group col-md-6">
                                <label>Emial </label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="far fa-envelope"></i></span>
                                    </div>
                                    <input type="email" name="email" value="<?php echo e(old('email',$configuracion->email)); ?>" class="form-control"  placeholder="Emial">
                                </div>
                            </div>  
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Teléfono</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fas fa-phone-alt"></i></span>
                                    </div>
                                    <input type="text" name="tel" value="<?php echo e(old('tel',$configuracion->tel)); ?>"  class="form-control"  placeholder="Teléfono">
                                </div>
                            </div> 
                            <div class="form-group col-md-6">
                                <label>WhatsApp</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="fab fa-whatsapp"></i></span>
                                    </div>
                                    <input type="tel" name="wsp" value="<?php echo e(old('wsp',$configuracion->wsp)); ?>" class="form-control"  placeholder="WhatsApp">
                                </div>
                            </div>  
                        </div>
                    
                        <div class="form-group">
                            <label><h4 class="primer-h4">Horarios</h4></label>
                            <hr>
                            <textarea class="form-control summernote" name="horarios"  rows="4"><?php echo e(old('horarios',$configuracion->horarios)); ?></textarea>
                        </div>

                        <div class="form-group col-md-12">
                            <label>Iframe del mapa</label>
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"> <i class="fas fa-map-marker-alt"></i></span>
                                </div>
                                <input type="text" name="iframe" value="<?php echo e(old('iframe',$configuracion->iframe)); ?>"  class="form-control">
                            </div> 
                        </div>
                        
                        <button type="submit" class="btn btn-primary mb-2" >Actualizar Configuración</button>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\mundo-hierro\resources\views/configuraciones/index.blade.php ENDPATH**/ ?>