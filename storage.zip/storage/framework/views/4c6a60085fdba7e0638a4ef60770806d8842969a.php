

<?php $__env->startSection('title','Post Venta'); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO POST VENTA-->


            <section class="section-post-venta">
                <?php $__currentLoopData = $servicios->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="post-venta-item" style="width: 100%">
                    <div class="imagen" style="width:50%; background-image: url( <?php echo e(asset(Storage::url($chunk->first->imagen->imagen))); ?> ); "></div>
                    <div class="imagen-text" style="width:50%;">
                        
                        <div class="text-display" >
                            <h4><?php echo e($chunk->first->titulo->titulo); ?></h4>
                            <h5><?php echo e($chunk->first->subtitulo->subtitulo); ?></h5>
                            
                            <p><?php echo e($chunk->first->descripcion->descripcion); ?></p>
                        </div>

                    </div>
                </div>
                <div class="post-venta-item" style="width: 100%">
                    <div class="imagen-text text-black" style="width:50%">
                        
                        <div class="text-display">
                            <h4><?php echo e($chunk->last()->titulo); ?></h4>
                            <h5><?php echo e($chunk->last()->subtitulo); ?></h5>
                                
                            <p><?php echo e($chunk->last()->descripcion); ?></p>

                        </div>

                    </div>

                    <div class="imagen"style="width:50%; background-image: url( <?php echo e(asset(Storage::url($chunk->last()->imagen))); ?> ); "></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>


            <section class="section-post-venta-contacto">
                <div class="container">
                    <h2>Contactá con nosotros</h2>
                    <p>Completa el formulario para que podamos asesorarte sobre nuestros servicios de Post Venta</p>
                    <form method="POST" action="<?php echo e(route('web.contactanos_post_venta')); ?>"> 
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-4">
                                <input class="box" name="nombre" placeholder="Ingresar nombre *">
                                <input class="box" name="email" placeholder="Ingrese su correo electrónico *">
                                <input class="box" name="empresa" placeholder="Empresa *">

                                <button type="submit" class="btn-post-venta" style="margin-top:25px;" >
                                    ENVIAR CONSULTA
                                </button>
                            </div>

                            <div class="col-4">
                                <input class="box" name="telefono" placeholder="Número de teléfono*">
                                <div> 
                                    <textarea class="box" name="comentarios" style="padding-top:19px; min-height:100px;">Mensaje</textarea>
                                </div>
                            </div>

                            <div class="col-4">
                                <h4> Seleccione el motivo de su consulta </h4>

                                <div class="form-check" style="margin-bottom: 5px;">
                                    <input class="form-check-input" type="checkbox" name="reparaciones" value="1">
                                    <label class="form-check-label">Reparaciones</label>
                                </div>
                                <div class="form-check" style="margin-bottom: 5px;">
                                    <input class="form-check-input" type="checkbox" name="repuestos_y_accesorios" value="1">
                                    <label class="form-check-label">Repuestos y accesorios</label>
                                </div>
                                <div class="form-check" style="margin-bottom: 5px;">
                                    <input class="form-check-input" type="checkbox" name="pintura" value="1">
                                    <label class="form-check-label">Pintura</label>
                                </div>
                                <div class="form-check" style="margin-bottom: 5px;">
                                    <input class="form-check-input" type="checkbox" name="capacitaciones" value="1">
                                    <label class="form-check-label">Capacitaciones</label>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </section>

            <section class="section-equipo">
                <div class="container">
                    <div class="row">
                        <div class="col-5">

                        </div>
                        <div class="col-7">
                            <h3>Plataforma Unipersonal ES30T1</h3>
                            <h4>ES30DB</h4>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><p> Capacidad</p><span> sp</span></li>
                                <li class="list-group-item"><p>Medidas</p><span> sp</span></li>
                                <li class="list-group-item"><p>Altura de Trabajo</p><span> sp</span></li>
                                <li class="list-group-item"><p>Altura de Plataforma</p><span> sp</span></li>
                                <li class="list-group-item"><p>Tamaño Global</p><span> sp</span></li>
                                <li class="list-group-item"><p>Min. distancia piso</p><span> sp</span></li>
                                <li class="list-group-item"><p>Distancia entre ejes</p><span> sp</span></li>
                                <li class="list-group-item"><p>Velocidad Ascenso y descenso</p><span> sp</span></li>
                                <li class="list-group-item"><p>Motor electrico</p><span> sp</span></li>
                                <li class="list-group-item"><p>Bateria</p><span> sp</span></li>
                                <li class="list-group-item"><p>Tamaño ruedas</p><span> sp</span></li>
                                <li class="list-group-item"><p>Peso neto</p><span> sp</span></li>
                            </ul>
                            <div style="display: flex; justify-content:space-between;margin-top:39px">
                                <button type="submit" class="btn-equipo-izquierda" >
                                    DESCARGAR FICHA TECNICA 
                                </button>
                                <button type="submit" class="btn-equipo-derecha" >
                                    CONSULTAR 
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="section-equipo-contacto">
                <div class="container">
                    <h2>Contactá con un experto</h2>
                    <form method="POST" action="<?php echo e(route('web.contactanos_post_venta')); ?>"> 
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-4">
                                <input class="box-equipo" name="nombre" placeholder="Ingresar nombre *">
                                <input class="box-equipo" name="email" placeholder="Ingrese su correo electrónico *">
                                <input class="box-equipo" name="empresa" placeholder="Empresa *">

                            </div>

                            <div class="col-4">
                                <input class="box-equipo" name="telefono" placeholder="Ingrese número de teléfono*">
                                <div> 
                                    <textarea class="box-equipo" name="comentarios" style="padding-top:19px; min-height:128px;">Mensaje</textarea>
                                </div>
                            </div>

                            <div class="col-4">
                                <h4> Tipo de operación </h4>
                                    <div class="form-check form-check-inline" style="margin-bottom: 5px;">
                                        <input class="form-check-input" type="checkbox" name="reparaciones" value="1">
                                        <label class="form-check-label">Venta</label>
                                    </div>
                                    <div class="form-check form-check-inline" style="margin-bottom: 5px;">
                                        <input class="form-check-input" type="checkbox" name="repuestos_y_accesorios" value="1">
                                        <label class="form-check-label">Alquiler</label>
                                    </div>
                            
                                
                                <button type="submit" class="btn-equipo" style="margin-top:25px;" >
                                    ENVIAR 
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
<!--FIN POST VENTA-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\pyramiz3\resources\views/web/servicios.blade.php ENDPATH**/ ?>