

<?php $__env->startSection('title','Empresa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container cont-empresa">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <?php $empresa = $empresas->first() ?>


                    <form action="<?php echo e(route('empresas.update',$empresa)); ?>" enctype="multipart/form-data" method="POST">
                                
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('put'); ?>
                        

                        <div class="form-group">
                            <label><h4 class="primer-h4">Párrafo Izquierda</h4></label>
                            <hr>
                            <textarea class="form-control summernote" name="parrafo_izquierda"  rows="4"><?php echo e(old('parrafo_izquierda',$empresa->parrafo_izquierda)); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label><h4 class="primer-h4">Párrafo Derecha</h4></label>
                            <hr>
                            <textarea class="form-control summernote" name="parrafo_derecha"  rows="4"><?php echo e(old('parrafo_derecha',$empresa->parrafo_derecha)); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary mb-2" >Actualizar Empresa</button>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/empresas/index.blade.php ENDPATH**/ ?>