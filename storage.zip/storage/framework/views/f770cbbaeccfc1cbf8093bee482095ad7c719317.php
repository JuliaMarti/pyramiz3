

<?php $__env->startSection('title',strtoupper($categoria->nombre)); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-categoria" style="margin-bottom:65px; margin-top:35px;">

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-3">
                
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', [$item->id,$familia])); ?>" class="  <?php echo e($categoria_id == $item->id ? 'cat-activa' : 'cat-no-activa'); ?>  list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item2->show && $item->id == $item2->categoria_id ): ?>
                            <a  href="<?php echo e(route('web.productos.producto',[$item2,$familia])); ?>" class="<?php echo e(false ? 'prod-activo' : 'prod-no-activo '); ?>list-group-item list-group-item-action list-trabajo" style=" padding-left:35px;" ><?php echo e($item2->nombre); ?></a>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-home-categorias col-9" style="margin-bottom: 24px"> 
                <div class="container-fluid">
                    <div class="row">

                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                <?php if($item->show): ?>
                                    
                                    <?php if($item->oferta): ?>
                                        <div class="col-12 col-md-4" style="border: 1px solid rgb(143, 134, 110, 0.3); padding-top:12px;">
                                            <a href="<?php echo e(route('web.productos.producto',[$item,$familia])); ?>" style="text-decoration: none">
                                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                                
                                                <div class="oferta">OFERTA</div>
                                            </div>
                                            </a>    
                                            <div class="text-box-categorias">
                                                <h4><?php echo e($item->nombre); ?></h4>
                                                <p class="descripcion"><?php echo e($item->descripcion); ?></p>
                                                <hr>
                                                <p style="font: normal normal 300 14px/17px Rubik;">Colores</p>
                                                <hr>
                                                <?php $__currentLoopData = $item->colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colorItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                
                                                    <div class="cuadrado-color" style="background-image: url(<?php echo e(asset(Storage::url($colorItem->color->imagen))); ?>); "></div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($item->precio_anterior); ?></span>$<?php echo e($item->precio); ?></p>
                                            
                                                <diametros-categorias diametros="<?php echo e($item->diametros); ?>"
                                                    ref="galeria"
                                                />
                                            
                                            
                                            </div> 
                                            </a>
                                            
                                        </div>

                                        <?php else: ?>
                                            <div class="col-12 col-md-4" style="border: 1px solid rgb(143, 134, 110, 0.3); padding-top:12px;" >
                                                <a href="<?php echo e(route('web.productos.producto',[$item,$familia])); ?>" style="text-decoration: none">
                                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); "></div>
                                                </a>        
                                                <div class="text-box-categorias">
                                                    <h4><?php echo e($item->nombre); ?></h4>
                                                    <p class="descripcion"><?php echo e($item->descripcion); ?></p>
                                                    <hr>
                                                    <p style="font: normal normal 300 14px/17px Rubik;">Colores</p>
                                                    
                                                    <?php $__currentLoopData = $item->colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colorItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                                    
                                                        <div class="cuadrado-color" style="background-image: url(<?php echo e(asset(Storage::url($colorItem->color->imagen))); ?>); "></div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <hr>
                                                    
                                                
                                                    <diametros-categorias diametros="<?php echo e($item->diametros); ?>" oferta="<?php echo e($item->oferta); ?>"
                                                        ref="galeria"
                                                    />
                                                    <p class="precio" style="text-align: center;">$<?php echo e($item->precio); ?></p>
                                                
                                                </div> 
                                                
                                            </div>   
                                        
                                    <?php endif; ?>


                                    
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    </div>
                </div>
            </section>
        </div>
    </div>

</section>
<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/web/productos/categoria.blade.php ENDPATH**/ ?>