

<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>


<div class="container cont-home">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <?php $home = $homes->first() ?>
                                
                    <form action="<?php echo e(route('homes.update',$home)); ?>" enctype="multipart/form-data" method="POST" >
                                
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('put'); ?>
                        
                        <div class="form-group">
                            <label><h4 class="primer-h4">Logo del encabezado</h4></label>
                            <hr>
                            <input type="file" accept="image/*" name="logo" value="<?php echo e(old('logo', $home->logo)); ?>" class="form-control-file" >
                        </div>
                        

                        <div class="form-group">
                            <label><h4 class="primer-h4">Logo del pie de página</h4></label>
                            <hr>
                            <input type="file" accept="image/*" name="logo_footer" value="<?php echo e(old('logo_footer', $home->logo_footer)); ?>" class="form-control-file" >
                        </div>


                        <div class="form-group">
                            <label><h4 class="primer-h4">Frase del pie de página</h4></label>
                            <input name="frase_footer" value="<?php echo e(old('frase_footer', $home->frase_footer)); ?>">
                        </div>

                        <h4>Sección Fogoneros</h4>
                        <hr>

                        <div class="form-group col-md-4">
                            <label>Frase </label>
                            <input type="text" name="fogo_frase" value="<?php echo e(old('fogo_frase', $home->fogo_frase)); ?>" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label>Imagen</label>
                            <input type="file" accept="image/*" name="fogo_foto" value="<?php echo e(old('fogo_foto',$home->fogo_foto)); ?>" class="form-control-file" >
                        </div>


                        <h4>Sección Cocina</h4>
                        <hr>
                        <div class="form-group col-md-4">
                            <label>Frase </label>
                            <input type="text" name="coc_frase" value="<?php echo e(old('coc_frase', $home->coc_frase)); ?>" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label>Imagen</label>
                            <input type="file" accept="image/*" name="coc_foto" value="<?php echo e(old('coc_foto',$home->coc_foto)); ?>" class="form-control-file" >
                        </div>

                        <h4>Sección Accesorios</h4>
                        <hr>
                        <div class="form-group col-md-4">
                            <label>Frase </label>
                            <input type="text" name="acc_frase" value="<?php echo e(old('acc_frase', $home->acc_frase)); ?>" class="form-control" >
                        </div>
                        <div class="form-group">
                            <label>Imagen</label>
                            <input type="file" accept="image/*" name="acc_foto" value="<?php echo e(old('acc_foto',$home->acc_foto)); ?>" class="form-control-file" >
                        </div>


                        <button type="submit" class="btn btn-primary mb-2" >Actualizar Home</button>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/homes/index.blade.php ENDPATH**/ ?>