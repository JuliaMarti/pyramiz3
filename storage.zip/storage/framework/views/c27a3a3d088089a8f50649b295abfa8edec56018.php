

<?php $__env->startSection('title','Trabajos'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

        <section class="section-home-categorias" style="margin-bottom: 24px"> 
            
            
            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($trabajo->show): ?>

                        <div class="col-12 col-md-3 " style="margin-bottom:38px ">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$trabajo)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($trabajo->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 ><?php echo e($trabajo->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>

                            
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>

<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/trabajos/trabajos.blade.php ENDPATH**/ ?>