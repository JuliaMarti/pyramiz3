

<?php $__env->startSection('title','Cliente'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('servicios.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de clientes</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('usuarios.update',$usuario)); ?>" enctype="multipart/form-data" method="POST">
                            
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            
                            <div class="form-group col-md-4">
                                <label>Tipo de usuario</label>
                                <select class="form-control" name="tipo_cliente">
                                    <option disabled>Elige una tipo de usuario...</option>
                                        <option <?php echo e(old('tipo_cliente', $usuario->tipo_cliente) == "publico" ? 'selected' : ''); ?> value="publico"> Público</option>
                                        <option <?php echo e(old('tipo_cliente', $usuario->tipo_cliente) == "mayorista" ? 'selected' : ''); ?> value="mayorista"> Mayorista</option>
                                        <option <?php echo e(old('tipo_cliente', $usuario->tipo_cliente) == "especial" ? 'selected' : ''); ?> value="especial"> Especial</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Enviar tipo de cliente</button>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>