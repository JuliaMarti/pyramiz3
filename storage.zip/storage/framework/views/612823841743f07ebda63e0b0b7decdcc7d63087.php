

<?php $__env->startSection('title','Qunuy'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->

<div id="carouselExampleIndicators" class="carousel carousel-home slide d-none d-md-block" data-bs-ride="carousel">
    
    <div class="carousel-indicators">
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="carousel-inner">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " style="background-image: url(<?php echo e(asset(Storage::url($imagen->imagen))); ?>)">
                        
                        <div class="carousel-overlay"></div>
                        
                        <div class="carousel-caption d-none d-md-block carousel-texto">
                            <h2 class="texto-empresa"><?php echo $imagen->texto; ?></h2>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>



<!--FIN CAROUSEL-INICIO-->


<div class="data-home">
    <div class="container ">
        <div class="row">
            <div class="col-12 col-md-4" style="display: flex">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-lg-4 mt-4 mt-md-0" >
                            <img src="<?php echo e(asset('img/home/envios.svg')); ?>" >  
                        </div>
                        <div class="col-12 col-lg-8 d-md-flex flex-wrap text-center text-md-left  mt-2 mt-lg-0" style="">
                            <h3>Enviamos tu compra</h3>
                            <h5>Entregas a todo el país</h5>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4" style="display: flex">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-lg-4 mt-4 mt-md-0">
                            <img src="<?php echo e(asset('img/home/pagos.svg')); ?>" >  
                        </div>
                        <div class="col-12 col-lg-8 d-md-flex flex-wrap text-center text-md-left  mt-2 mt-lg-0" style="">
                            <h3>Pagá como quieras</h3>
                            <h5>Tarjetas de crédito o efectivo</h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-4" style="display: flex">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12 col-lg-4 mt-4 mt-md-0">
                            <img src="<?php echo e(asset('img/home/seguridad.svg')); ?>" > 
                        </div>
                        <div class="col-12 col-lg-8 d-md-flex flex-wrap text-center text-md-left  mt-2 mt-lg-0" style="padding:0;">
                            <h3>Comprá con seguridad</h3>
                            <h5>Tus datos siempre protegidos</h5>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>



<!--INICIO SECCIÓN PRODUCTOS-->




<!--FIN SECCIÓN PRODUCTOS-->


<!--INICIO SECCIÓN PRODUCTOS-->


        <section class="section-home-categorias  section-categoria" style="margin-bottom:0px;"> 
            <h3 style="margin-top:40px;">Productos destacados</h3>

            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->destacado): ?>
                        <?php if($item->show): ?>
                            <?php if($item->oferta): ?>
                                <div class="col-12 col-md-3" >
                                    <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                        <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                    </div>
                                        
                                    <div class="text-box-categorias">
                                        <h4><?php echo e($item->nombre); ?></h4>
                                        <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($item->precio_anterior); ?></span>$<?php echo e($item->precio); ?></p>
                                    </div> 
                                    </a>
                                    
                                </div>

                            <?php else: ?>
                                <div class="col-12 col-md-3" >
                                    <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); "></div>
                                            
                                        <div class="text-box-categorias">
                                            <h4><?php echo e($item->nombre); ?></h4>
                                            <p class="precio" style="text-align: right;">$<?php echo e($item->precio); ?></p>
                                        </div> 
                                    </a>
                                </div>   
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                    

                </div>
            </div>
        </section>

<!--FIN SECCIÓN PRODUCTOS-->





<!--INICIO SECCIÓN FAMILIAS-->

<div class="section-home-flias">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-6 fogoneros flia" style="background-image: url(<?php echo e(asset(Storage::url($home->fogo_foto))); ?>); ">
                <div class="overlay"></div>
                <div class="text-box">
                    <h4>Fogoneros</h4>
                    <p><?php echo e($home->fogo_frase); ?></p>
                    <a href="">
                        VER PRODUCTOS
                        <hr>
                    </a>
                </div>
            </div>

            <div class="col-12 col-md-6">
                <div class="container-fluid" style="height: 100%;">
                    <div class="row" style="height: 100%;">
                        <div class=" col-12 flia" style="background-image: url(<?php echo e(asset(Storage::url($home->coc_foto))); ?>); ">
                            <div class="text-box">
                                <h4>Accesorios</h4>
                                <p><?php echo e($home->coc_frase); ?></p>
                                <a href="">
                                    VER PRODUCTOS
                                    <hr>
                                </a>
                            </div>
                        </div>
                        <div class=" col-12 flia" style="background-image: url(<?php echo e(asset(Storage::url($home->acc_foto))); ?>); margin-top:30px; ">
                            <div class="text-box">
                                <h4>Cocina</h4>
                                <p><?php echo e($home->acc_frase); ?></p>
                                <a href="">
                                    VER PRODUCTOS
                                    <hr>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--FIN SECCIÓN FAMILIAS-->





<!--INICIO SECCIÓN REPRESENTANTES-->

        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/web/index.blade.php ENDPATH**/ ?>