

<?php $__env->startSection('title','Descargas'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-descargas">
    <div class="container">
        <div class="row">
            <p>Aquí podrás encontrar toda la información técnica necesaria sobre cada equipo. Hay disponibles tablas de corte, manuales, técnicas de corte, etc.</p>
        </div>
        <div class="row">
            <div class="col-4" >
                <div class="list-group  list-group-flush">
                    <?php $__currentLoopData = $descargables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->show): ?>
                            <a href="<?php echo e(route('web.descargas', $item->id)); ?>" style="<?php echo e($desc_id == $item->id ? 'color: white; background-color:#04367D;' : ''); ?>" class="list-group-item list-group-item-action"><?php echo e($item->name); ?></a>

                        <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
            <div class="col-8" style="padding-left:42px;">
                <table class="table-descargas" >
                    <thead> 
                        <tr>
                            <th scope="col" style="width:65%; text-align:left;">NOMBRE</th>
                            <th scope="col">FORMATO</th>
                            <th scope="col">DESCARGAR</th>
                        </tr>
                    </thead>
                    <tbody> 
                        <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                            <td style="text-align:left;"><?php echo e($info->nombre); ?></td>
                            <td><?php echo e($info->formato); ?></td>
                            <td><a href="<?php echo e($info->descarga); ?>"><i class="fas fa-download"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody> 
                </table>   
            </div>     
        </div>
    <div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/web/descargas.blade.php ENDPATH**/ ?>