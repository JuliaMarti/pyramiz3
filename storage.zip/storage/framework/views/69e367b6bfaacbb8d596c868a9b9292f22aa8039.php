

<?php $__env->startSection('title','Contacto'); ?>

<?php $__env->startSection('content'); ?>








<section class="section-direcciones">
    <div class="container">
        <div class="row" style="display: flex">
            <div class="accordion accordion-flush col-4 d-none d-md-block" id="accordionFlushExample">
                <?php $__currentLoopData = $direcciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $direccionItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($direccionItem->show): ?>

                        <div class="accordion-item">
                            <h3 class="accordion-header " id="flush-heading<?php echo e($i); ?>">
                                    <button class="accordion-button <?php echo e($direccion->id == $direccionItem->id ? '' : 'collapsed'); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapse<?php echo e($i); ?>" aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>" aria-controls="flush-collapse<?php echo e($i); ?>">
                                        <?php echo e($direccionItem->nombre); ?>

                                    </button>
                            </h3>
                            <div id="flush-collapse<?php echo e($i); ?>" class="accordion-collapse collapse <?php echo e($direccion->id == $direccionItem->id ? 'show' : ''); ?>" aria-labelledby="flush-heading<?php echo e($i); ?>" data-bs-parent="#accordionFlushExample">
                                
                                
                                <div class="accordion-body" >
                                    <div class="accordeon-body-item">
                                        <i class="fas fa-map-marker-alt"></i><p><?php echo e($direccionItem->direccion); ?></p>
                                    </div>
                                    <div class="accordeon-body-item">
                                        <i class="fas fa-phone-alt"></i><div style="margin-bottom:16px;"><?php echo $direccionItem->telefonos; ?></div>
                                    </div>
                                     <?php if($direccionItem->email): ?>
                                         
                                        <div class="accordeon-body-item">
                                            <i class="far fa-envelope" style="margin-top: 4px;"></i><p><?php echo e($direccionItem->email); ?></p>
                                        </div>
                                     <?php endif; ?>

                                </div>
                            
                            
                            </div>
                        </div>
    
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    
            <div class="col-12 col-md-8" id="map" ></div>
            
    
        </div>
    </div>

</section>


<section class="section-contacto">
    <div class="container">
        
        <h2>Completa el formulario</h2>
        <p>Contanos en qué podemos ayudarte</p>

        <form method="POST" action="<?php echo e(route('web.contactanos',$direcciones->first->id)); ?>"> 
            <?php echo csrf_field(); ?>
            <div class="row">
        
                <div class="col-12 col-md-6">
                    <input class="box" name="nombre" placeholder="Ingresar nombre *">
                    <input class="box" name="telefono" placeholder="Ingrese tu teléfono *">
                    <input class="box" name="mensaje" placeholder="Mensaje">
                </div>
        
                <div class="col-12 col-md-6">
                    <input class="box" name="email" placeholder="Ingrese su correo electrónico *">
                    <input class="box" name="empresa" placeholder="Empresa">
                    <button type="submit" class="btn-contacto" >
                        ENVIAR CONSULTA
                    </button>
                </div>
                
            </div>
        </form>   
        
        <?php if(session('info')): ?>
            <script>
                alert("<?php echo e(session('info')); ?>");
            </script>
        <?php endif; ?>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/web/contacto.blade.php ENDPATH**/ ?>