<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $__env->yieldContent('title'); ?></title>
    

    <!-- Bootstrap -->
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Fira+Sans:ital,wght@0,300;0,400;1,300;1,400;1,500;1,600&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    
    
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>



    <script src="https://www.google.com/recaptcha/api.js" async defer></script>




    <script>
        function initMap() {
            const myLatLng = { lat: -34.465840080495454, lng:-58.68872218477411 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 5,
                center: { lat: -33.07131868088422, lng:-60.64669768481039 },
            });
            new google.maps.Marker({
                position: myLatLng,
                map,
                title: "Pyramiz, Casa Central",
            });

            new google.maps.Marker({
                position: { lat: -33.07131868088422, lng:-60.64669768481039 },
                map,
                title: "Sucursal Rosario",
            });
        
            new google.maps.Marker({
                position: { lat: -24.79043678408699, lng:-65.36091468499855 },
                map,
                title: "Sucursal Salta",
            });
        }
        
        
    </script>

    </head>

    <body>
<!--INICIO HEADER-->

        <div style="margin-bottom:6.5rem;">.</div>
        <header>
                <div class="blackBg header-top">
                    <div class="container" style="display: flex; justify-content: space-between;">
                            <div class="fondo"></div>
                            <div>
                                <div class="header-top-box">
                                    
        

                                    <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="header-top-item">
                                            <a href="<?php echo e($red->url); ?>" <?php echo e($red->url ? 'target=”_blank”' : ''); ?>  ><?php echo $red->icono; ?></a>         
                                        </div>                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>

                        </div>
                    </div>
                </div>

                <nav>
                    <div class="container" style="display: flex; justify-content: space-between;">
                        
                            <a href="<?php echo e(route('web.home')); ?>" class="col-8 col-md-3">
                                <img src="<?php echo e(asset(Storage::url($home->logo))); ?>"  alt="Pyramiz">
                            </a>

                            <button class="nav-btn d-flex d-md-none" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fas fa-bars"></i></button>
                    
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.home')); ?>">INICIO</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'empresa' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.empresa')); ?>">EMPRESA</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'equipos' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.equipos.equipos')); ?>">EQUIPOS</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.productos.productos')); ?>">PRODUCTOS</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'servicios' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.servicios',1)); ?>">POST VENTA</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'ofertas' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.ofertas')); ?>">OFERTAS</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'blogs' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.blogs','todas')); ?>">BLOG</a>
                                        </li>
                                        <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                            <a class="nav-link" href="<?php echo e(route('web.contacto',$direccionesFooter->first->id)); ?>">CONTACTO</a>
                                        </li>                                        </div>
                                        <div class="modal-footer">
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <ul class="nav d-none d-md-flex">
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.home')); ?>">INICIO</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'empresa' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.empresa')); ?>">EMPRESA</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'equipos' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.equipos.equipos')); ?>">EQUIPOS</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.productos.productos')); ?>">PRODUCTOS</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'servicios' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.servicios',1)); ?>">POST VENTA</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'ofertas' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.ofertas')); ?>">OFERTAS</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'blogs' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.blogs','todas')); ?>">BLOG</a>
                                </li>
                                <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                    <a class="nav-link" href="<?php echo e(route('web.contacto',$direccionesFooter->first->id)); ?>">CONTACTO</a>
                                </li>

                                <li class="buscador" style="position: relative;">
                                    <form method="GET" action="<?php echo e(route('web.busqueda')); ?>"> 
                                        <?php echo csrf_field(); ?>
                                        
                                        <input type="text" placeholder="Buscar" name="busqueda">

                                        <button type="submit" > <i class="fas fa-search"></i> </button>
                                    </form>
                                </li>
                            </ul>
                    </div>
                </nav>  
        </header>

        <?php if($breadcrumb[0]['title'] !='home' && $breadcrumb[0]['title'] !='empresa' ): ?>
            <div class="header-bottom">
                <div class="fondo"></div>
                <div class="container header-bottom-cont">
                    <div class="header-bottom-text">
                        <h2><?php echo e($breadcrumb[0]['title']); ?></h2>
                        <h3></h3>
                    </div>
                    <div class="header-breadcrumb">
                        <a href="<?php echo e(route('web.home')); ?>">INICIO</a>
                        <?php $__currentLoopData = $breadcrumb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $bread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <a class="<?php echo e($key == (count($breadcrumb)-1) ? 'active-link' : ''); ?> " href="<?php echo e(route($bread['link'],$bread['cat'] ? $bread['cat'] : '' )); ?>"><?php echo e($bread['title']); ?></a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
<!--FIN HEADER-->
    
        <main>

            <?php echo $__env->yieldContent('content'); ?>

        </main>

<!--INICIO FOOTER-->        

        <footer>
            <div class="footer-top">
                
                <a class="d-none d-md-flex" href="https://api.whatsapp.com/send?phone=<?php echo e($configuracion->wsp); ?>"  <?php echo e($configuracion->wsp ? 'target=”_blank”' : ''); ?> ><div class="border-wsp"> <i class="fab fa-whatsapp"> </i></div> </a>
            </div>

            <div class="footer-info d-none d-md-flex">
                <div class="container footer-box">
                    <div class="row">

                        <div class="col-3 d-none d-sm-none d-md-block" >
                            <img src="<?php echo e(asset(Storage::url($home->logo_footer))); ?>">
                            
                        </div>

                        <div class="col d-none d-sm-none d-md-block" >
                            

                        </div>

                        <div class="col d-none d-sm-none d-md-block" style="padding-top:37px;">
                            
                        </div>

                        <?php $__currentLoopData = $direccionesFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemDireccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3 p-0 d-none d-sm-none d-md-block">
                            <h5><?php echo e($itemDireccion->nombre); ?></h5>
                    
                            <div class="item-contact" style="margin-bottom: 18px;">
                                <i class="fas fa-map-marker-alt"></i>
                                <a><?php echo e($itemDireccion->direccion); ?></a>
                                <p></p>
                            </div>
                            
                            <div class="item-contact" style="margin-bottom: 18px;">
                                    <i class="far fa-envelope"></i> 
                                    <a href="mailto:<?php echo e($itemDireccion->email); ?>" target=”_blank”><?php echo e($itemDireccion->email); ?></a>
                            </div>
                                
                            <div class="item-contact" style="margin-bottom: 18px;">
                                <i class="fas fa-phone-alt"></i>
                                <div style="margin-bottom:16px;"><?php echo $itemDireccion->telefonos; ?></div>
                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                    </div>
                </div>             
            </div>

            <div class=" footer-bottom darkBlackBg d-none d-md-flex">
                <div class="container">
                    <p>© Copyright 2021 Pyramiz. Todos los derechos reservados</p>
                </div>
            </div>
        </footer>

<!--FIN FOOTER-->    
<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <!-- Async script executes immediately and must be after any DOM elements used in callback. -->
    <script
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAZUlidy4Exa3bvZLRh4qgqx4lwlLy6khw&callback=initMap&libraries=&v=weekly"
    async
    ></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>