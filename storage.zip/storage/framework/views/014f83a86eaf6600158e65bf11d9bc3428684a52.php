

<?php $__env->startSection('title','Producto <?php echo e($product->name); ?>'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h1>Producto <?php echo e($product->name); ?></h1>

                    <a href="<?php echo e(route('products.index')); ?>">Volver a listado de productos </a>
                    <br>
                    <a href="<?php echo e(route('products.edit',$product)); ?>">Editar este producto</a>
                    <br>
                    <br>
                    <br>
                    <br>
                
                    <p> Orden:  <?php echo e($product->orden); ?> </p> 
                    <p> Nombre:  <?php echo e($product->name); ?> </p> 
                    <p> Mostrar:  <?php echo e($product->show); ?> </p> 
                    <p> Descripción:  <?php echo e($product->description); ?> </p> 
                    <p> Imagen Principal:  <?php echo e($product->imagen_principal); ?> </p> 
                
                    <br>
                    <p>Medidas</p>
                    <p> Ancho máximo:  <?php echo e($product->ancho_maximo); ?> </p> 
                    <p> Largo máximo:  <?php echo e($product->largo_maximo); ?> </p> 
                
                    <br>
                    <p>Equipamiento</p>
                    <p> Plasma HD:  <?php echo e($product->plasma_HD); ?> </p> 
                    <p> Plasma O2:  <?php echo e($product->plasma_O2); ?> </p> 
                    <p> Plasma Aire:  <?php echo e($product->plasma_aire); ?> </p> 
                    <p> Oxicorte:  <?php echo e($product->oxicorte); ?> </p> 
                    <p> Marcador Plasma:  <?php echo e($product->marcador_plasma); ?> </p> 
                    <p> Marcador Neumático:  <?php echo e($product->marcador_neumatico); ?> </p> 
                    <p> Control de altura Plasma:  <?php echo e($product->control_altura_plasma); ?> </p> 
                    <p> Control de altura Oxicorte:  <?php echo e($product->control_altura_oxicorte); ?> </p> 
                    <p> Cabezal biselador plasma:  <?php echo e($product->cabezal_biselador_plasma); ?> </p> 
                    <p> Cabezal bicelador oxicorte:  <?php echo e($product->cabezal_biselador_oxicorte); ?> </p> 
                
                    <br>
                    <p> Componentes </p>
                    <p> Vías de desplazamiento:  <?php echo e($product->vias_desplazamiento); ?> </p> 
                    <p> Bases de apoyo:  <?php echo e($product->bases_apoyo); ?> </p> 
                    <p> Cremalleras de presición:  <?php echo e($product->cremalleras_presicion); ?> </p> 
                    <p> Servo Motores:  <?php echo e($product->servo_motores); ?> </p> 
                    <p> Cajas reductoras:  <?php echo e($product->cajas_reductoras); ?> </p> 
                    <p> CNC:  <?php echo e($product->CNC); ?> </p> 
                    <p> Panel Operador:  <?php echo e($product->panel_operador); ?> </p> 
                    <p> Pantalla Industrial:  <?php echo e($product->pantalla_industrial); ?> </p> 
                    <p> Límites de carrera:  <?php echo e($product->limites_carrera); ?> </p> 
                    <p> Características principales (izquierda):  <?php echo e($product->lista_izquierda); ?> </p> 
                    <p> Características principales (derecha):  <?php echo e($product->lista_derecha); ?> </p> 
                    <p> Características de display:  <?php echo e($product->lista_display); ?> </p>
                    <p> Imagen display:  <?php echo e($product->imagen_display); ?> </p>  
                    <p> Características de corte:  <?php echo e($product->lista_corte); ?> </p> 
                    <p> Imagen corte:  <?php echo e($product->imagen_corte); ?> </p> 
                    <p> Imagen de características técnicas:  <?php echo e($product->imagen_caract_tecnicas); ?> </p> 
                
                    <br>
                    <p>Dimensiones útiles de corte :</p>
                    <p> Ancho:  <?php echo e($product->dimension_util_corte_ancho); ?> </p> 
                    <p> Alto:  <?php echo e($product->dimension_util_corte_alto); ?> </p> 
                
                    <br>
                    <p> Dimensiones generales:<p>
                    <p> Ancho:  <?php echo e($product->ancho); ?> </p> 
                    <p> Alto:  <?php echo e($product->alto); ?> </p> 
                    <p> Profundidad:  <?php echo e($product->profundidad); ?> </p> 
                
                    <br>
                    <p>Especificaciones ténicas </p>
                    <p> Sistemas de corte:  <?php echo e($product->sistemas_de_corte); ?> </p> 
                    <p> Velocidad máxima de desplazamiento:  <?php echo e($product->velocidad_max_desplazamiento); ?> </p> 
                    <p> Velocidad máxima de corte:  <?php echo e($product->velocidad_max_corte); ?> </p> 
                    <p> Transmisiones:  <?php echo e($product->transmisiones); ?> </p> 
                    <p> Sistema de guiado:  <?php echo e($product->sistema_de_guiado); ?> </p> 
                    <p> Motorización:  <?php echo e($product->motorizacion); ?> </p> 
                    <p> Estructura mecánica:  <?php echo e($product->estructura_mecanica); ?> </p> 
                    <p> Control de altura Plasma:  <?php echo e($product->control_altura_plasma_2); ?> </p> 
                    <p> Sistema de Detección de Chapa:  <?php echo e($product->sistema_deteccion_chapa); ?> </p> 
                    <p> Software:  <?php echo e($product->software_CAD_CAM); ?> </p> 
                    <p> Control:  <?php echo e($product->control); ?> </p> 
                    <p> Display:  <?php echo e($product->display); ?> </p> 
                    <p> Comunicación:  <?php echo e($product->comunicacion); ?> </p> 
                    <p> Alimentacion eléctrica:  <?php echo e($product->alimentacion_electrica); ?> </p> 
                    <p> Peso:  <?php echo e($product->peso); ?> </p> 
                </div>
            </div>
        </div>
    </div>
</div>

    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/products/show.blade.php ENDPATH**/ ?>