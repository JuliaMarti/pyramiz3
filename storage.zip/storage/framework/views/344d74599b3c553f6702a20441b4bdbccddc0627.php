

<?php $__env->startSection('title','Descargas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container cont-descargas">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                <button type="button" class="btn btn-success" style="float:right;"><a style ="color:white;" href="<?php echo e(route('descargables.create')); ?>"><i class="fas fa-plus" style ="color:white; margin-right:7px;" ></i>AÑARDIR</a></button>
                <br>


                <?php $__currentLoopData = $descargables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $descargable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <br>
                    <div class="card" style="margin-top:15px;">
                
                        <div class="card-body p-0" >

                            <div style="position:relative;  padding-top:15px;">
                                <h4 style="color:#03224e;font-size: 24px; margin-bottom: 15px; margin-left:5px;"><?php echo e($descargable->name); ?></h4>

                                <div style="display:flex; position:absolute; left: 83%; top:10%;"> 
                                    <button type="button" class="btn btn-success" style="margin-right: 5px;"> <a style ="color:white;" href="<?php echo e(route('infos.create',$descargable)); ?>"> <i class="fas fa-plus" style ="color:white; margin-right:7px;" ></i></a></button>
                                    <button type="button" class="btn btn-primary" style="margin-right:5px;"><a style ="color:white; "href="<?php echo e(route('descargables.edit',$descargable)); ?>"><i class="far fa-edit"></i></a></button>
                                    <form action="<?php echo e(route('descargables.destroy', $descargable)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submite" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                            
                                    </form>
                                </div>
                            </div>
                                                                            
                            <table class="table" style="width: 100%">
                                <thead style="color:#03224e"> 
                                    <tr>
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Formato</th>
                                        <th scope="col">Archivo</th>
                                        <th scope="col">Mostrar</th>
                                        <th scope="col">Orden</th>
                                        <th scope="col">Acciones</th>
                                    </tr>
                                </thead>

                                <tbody>  
                                    <?php $__currentLoopData = $descargable->infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            

                                                <tr>
                                                    <td><?php echo e($info->nombre); ?></td>
                                                    <td><?php echo e($info->formato); ?></td>
                                                    <td  style="max-width: 250px;"><?php echo e($info->descarga); ?></td>
                                                    <td><?php echo e($info->show ? 'Si' : 'No'); ?></td>
                                                    <td><?php echo e($info->orden); ?></td>
                                                    <td style="display:flex;">
                                                        <button type="button" class="btn btn-primary" style="margin-right:5px;"><a style ="color:white;"href="<?php echo e(route('infos.edit',$info)); ?>"><i class="far fa-edit"></i></a></button>
                                                        <form action="<?php echo e(route('infos.destroy', $info)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submite" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                                
                                                        </form>
                                                    </td>
                                                </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>    

                            <hr style="font-weight: bold; color:black">

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/descargas/index.blade.php ENDPATH**/ ?>