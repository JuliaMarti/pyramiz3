

<?php $__env->startSection('title','Sección Nueva'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('show_productos.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de productos</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('seccionesP.store', $producto)); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>

                                <div class="form-group col-md-3">
                                    <label>Título</label>
                                    <input type="text" name="titulo" value="<?php echo e(old('titulo')); ?>" class="form-control" placeholder="Título">
                                </div>
                            </div>

                            <div class="form-group">
                                <label><h4 class="primer-h4">Párrafo</h4></label>
                                <hr>
                                <textarea class="form-control" name="texto"  rows="4"><?php echo e(old('texto')); ?></textarea>
                            </div>

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>
                            <br>

                            <button type="submit" class="btn btn-primary mb-2">Enviar sección</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/secciones_p/create.blade.php ENDPATH**/ ?>