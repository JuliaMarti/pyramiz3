<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <p>Nombre: <?php echo e($info['nombre']); ?></p>
    <p>Apellido: <?php echo e($info['apellido']); ?></p>
    <p>Email: <?php echo e($info['email']); ?></p>
    <p>Empresa: <?php echo e($info['empresa']); ?></p>

    <p>Comentarios: </p>
    <p><?php echo e($info['comentarios']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/emails/contactanos.blade.php ENDPATH**/ ?>