

<?php $__env->startSection('title','Post Venta'); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO BLOG-->


<section class="section-home-noticias" style="margin-top:42px"> 
    <div class="container">
        <div class="row">

            
            <?php if($filtro == 'todas'): ?>
                <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($noticia->destacar && $noticia->show): ?>
                    <div class="col-12 col-md-6 item-noticia">
                        <div>
                            <div class="img-border-noticias" style="background-image: url(<?php echo e(asset(Storage::url($noticia->imagen))); ?>); "></div>
                            <h4><?php echo e($noticia->categoria->nombre); ?></h4>
                            <h5><?php echo e($noticia->titulo); ?></h5>

                            <p class="nombre-noticia" ><?php echo e($noticia->descripcion); ?></p>
                        </div>
                        <a  href="<?php echo e(route('web.blogs.noticia',$noticia)); ?>" style="text-decoration: none"><button class="btn-noticias">LEER MÁS</button></a>
                    </div>

                    <?php else: ?>
                        <?php if($noticia->show): ?>
                        <div class="col-12 col-md-6 d-none d-md-flex" style="margin-top:67px;">
                            <div class="container item-blog">
                                <div class="row">
                                    <div class="img-border-blog col-4" style="background-image: url(<?php echo e(asset(Storage::url($noticia->imagen))); ?>); ">
                                    </div>
                                    <div class="col-8 item-blog-text">
                                        <h4><?php echo e($noticia->categoria->nombre); ?></h4>
                                        <h5><?php echo e($noticia->titulo); ?></h5>
                
                                        <p class="nombre-noticia" ><?php echo e($noticia->descripcion); ?></p>
                                        
                                        <a href="<?php echo e(route('web.blogs.noticia',$noticia)); ?>" class="btn-blog">LEER MÁS</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
            <?php else: ?>
                <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($noticia->claseblog_id == $filtro && $noticia->show): ?>
                    <div class="col-12 col-md-6 item-noticia ">
                        <div>
                            <div class="img-border-noticias" style="background-image: url(<?php echo e(asset(Storage::url($noticia->imagen))); ?>); "></div>
                            <h4><?php echo e($noticia->titulo); ?></h4>
                            <h5><?php echo e($noticia->subtitulo); ?></h5>

                            <p class="nombre-noticia" ><?php echo e($noticia->descripcion); ?></p>
                        </div>
                        <a  href="<?php echo e(route('web.blogs.noticia',$noticia)); ?>" style="text-decoration: none"><button class="btn-noticias">LEER MÁS</button></a>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
    </div>
</section>



<!--FIN BLOG-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/web/blogs/blogs.blade.php ENDPATH**/ ?>