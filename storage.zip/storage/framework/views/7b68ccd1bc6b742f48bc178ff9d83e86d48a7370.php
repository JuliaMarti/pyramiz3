

<?php $__env->startSection('title', strtoupper($producto->nombre) ); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO PRODUCTO-->


<section class="section-categoria" >

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-3  d-none d-md-flex">
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', $item->id)); ?>" style="<?php echo e($categoria_id == $item->id ? 'color: white; background-color:#000000;' : ''); ?>" class="list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product->show && $product->categoria_id == $item->id): ?>
                        <a  href="<?php echo e(route('web.productos.producto',$product)); ?>" class="list-group-item list-group-item-action list-producto" style="<?php echo e($producto->id == $product->id ? 'background-color:#DBDBDB;' : 'background-color:#F8F8F8;'); ?>" ><?php echo e($product->nombre); ?></a>

                    <?php endif; ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-equipo col-9">
                <div class="container" style="padding-left:3px">
                    <div class="row">
                        <div class="col-12 col-md-7">
                            <div class="box-clase">
                                <div class="img-border-equipos" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen))); ?>); "></div>
                            </div>

                            <div class="container" style="padding-right:0; padding-left:0;">
                                <div class="row" style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2);">
                                    <?php $__currentLoopData = $colores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="box-clase-mini col-2" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                    <div class="overlay"></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>
                        <div class="col-12 col-md-5" style="display: flex; flex-direction:column; justify-content:space-between">
                            <div>
                                <h3><?php echo e($producto->nombre); ?></h3>
                                <p><?php echo e($producto->presentacion); ?></p>
                                <hr>
                                <h4>Normas</h4>
                                <p><?php echo e($producto->normas); ?></p>
                            </div>

                            <div style="display: flex; justify-content:space-between;margin-top:39px">
                                    <a  href="<?php echo e(asset(Storage::url($producto->ficha_tecnica))); ?>"  download>
                                    <button type="submit" class="btn-equipo-izquierda"  >
                                        Descargar ficha
                                    </button>
                                    </a>
                                    <a  href="<?php echo e(route('web.contacto')); ?>" >
                                        <button type="submit" class="btn-equipo-derecha" >
                                                Consultar
                                        </button>
                                    </a>
                            </div>
                        </div>
                    </div>
                    <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:40px;">
                        <div class="col-12" style="background-color: #000000; padding-top:5px;"><h5>Descripción</h5></div>
                    </div>
                    <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:44px;">
                        <div class="col-12 descripcion"> <?php echo $producto->descripcion; ?> </div>
                    </div>

                    <?php if($producto->show_imagen_grafico): ?>
                        <div class="row  d-none d-md-flex"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:40px; margin-bottom:89px; display:flex; justify-content:center;">
                            <div class="grafico col-8" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen_grafico))); ?>); ">
                        </div>
                        </div>
                    <?php endif; ?>

                
                    <div class="row  d-none d-md-flex"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); display:flex; justify-content:center;">
                        <?php if($producto->show_medidas): ?>   

                            <div class="col-4"> <div class="caracteristicas">   <h5>ESPESOR</h5> <div class="parf"><div><?php echo $producto->espesor; ?> </div></div>   </div>  </div>
                            <div class="col-4"> <div class="caracteristicas">   <h5>LARGO</h5> <div class="parf"><div><?php echo $producto->largo; ?> </div></div>   </div></div>
                            <div class="col-4"> <div class="caracteristicas">   <h5>ANCHO</h5> <div class="parf"><div><?php echo $producto->ancho; ?> </div></div>   </div></div>

                        <?php endif; ?>
                        <hr class="col-12" style="color:#000000; height:o.5px; margin-top:62px;">
                    </div>

                    <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); display:flex; justify-content:center;">
                        <h5 class="col-12" style="font: normal normal normal 25px/30px Open Sans;letter-spacing: 0.88px;color: #2B2B2B; margin-top:24px; margin-bottom:75px;">Productos relacionados</h5>
                        
                        <?php if($relacionado_1): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.productos.producto',$relacionado_1)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_1->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_1->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if($relacionado_2): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.productos.producto',$relacionado_2)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_2->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_2->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if($relacionado_3): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.productos.producto',$relacionado_3)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_3->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_3->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
            </section>
        </div>
    </div>

</section>



<!--FIN PRODUCTO-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundo-hierro\resources\views/web/productos/producto.blade.php ENDPATH**/ ?>