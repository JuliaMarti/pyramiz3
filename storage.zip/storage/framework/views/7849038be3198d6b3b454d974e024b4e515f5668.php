

<?php $__env->startSection('title','Nuevo Producto'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('show_productos.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de productos</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('productos.store')); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Nombre </label>
                                    <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control" placeholder="Nombre">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Precio </label>
                                    <input step=".01" type="number" name="precio" value="<?php echo e(old('precio')); ?>" class="form-control">
                                </div>
                            </div>


                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Unidad de venta </label>
                                    <input type="number" name="unidad_de_venta" value="<?php echo e(old('unidad_de_venta')); ?>" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Elige una categoría para el equipo</label>
                                    <select class="form-control" name="categoria_id">
                                        <option disabled>Elige una categoría...</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('categoria_id') == $categoria->id ? 'selected' : ''); ?> value="<?php echo e($categoria->id); ?>"> <?php echo e($categoria->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('destacado') == 1 ? 'checked' : ''); ?> name="destacado" value="1">
                                <label class="form-check-label">Producto destacado</label>
                            </div>


                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>


                            
                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('oferta') == 1 ? 'checked' : ''); ?> name="oferta" value="1">
                                <label class="form-check-label">Está en oferta</label>
                            </div>

                            <div class="form-group col-md-4">
                                <label>Precio en oferta</label>
                                <input type="number" step=".01" name="precio_oferta" value="<?php echo e(old('precio_oferta')); ?>" class="form-control">
                            </div>

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('hay_stock') == 1 ? 'checked' : ''); ?> name="hay_stock" value="1">
                                <label class="form-check-label">Hay stock</label>
                            </div>





                            <div class="form-group col-md-4">
                                <label>Elige tres poductos relacionados</label>
                                <select class="form-control" name="relacionado_1">
                                    <option disabled>Elige una producto...</option>
                                    <?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacionado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('relacionado_1') == $relacionado->id ? 'selected' : ''); ?> value="<?php echo e($relacionado->id); ?>"> <?php echo e($relacionado->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <select class="form-control" name="relacionado_2">
                                    <option disabled>Elige una producto...</option>
                                    <?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacionado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('relacionado_2') == $relacionado->id ? 'selected' : ''); ?> value="<?php echo e($relacionado->id); ?>"> <?php echo e($relacionado->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group col-md-4">
                                <select class="form-control" name="relacionado_3">
                                    <option disabled>Elige una producto...</option>
                                    <?php $__currentLoopData = $relacionados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacionado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('relacionado_3') == $relacionado->id ? 'selected' : ''); ?> value="<?php echo e($relacionado->id); ?>"> <?php echo e($relacionado->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Imagen</label>
                                <input type="file" accept="image/*" name="imagen" value="<?php echo e(old('imagen')); ?>" class="form-control-file" >
                            </div>

                            <div class="form-group">
                                <label>Descripción</label>
                                <textarea class="form-control" name="descripcion"  rows="4"><?php echo e(old('descripcion')); ?></textarea>
                            </div>
                            <br>


                            <div class="form-group ">
                                <label>Especificaciones</label>
                                <textarea class="form-control summernote" name="tabla" ><?php echo e(old('tabla')); ?></textarea>
                            </div>


                            <button type="submit" class="btn btn-primary mb-2">Enviar producto</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/productos/create.blade.php ENDPATH**/ ?>