

<?php $__env->startSection('title','Contacto'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-contacto">
    
<?php echo $configuracion->iframe; ?>

    <div class="container">
        
        <form method="POST" enctype="multipart/form-data"  action="<?php echo e(route('web.contactanos')); ?>"> 
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12 col-md-4">
                    <p >Para más información, ingrese sus datos y complete el formulario</p>

                    <div class="item-contact">
                        <i class="fas fa-map-marker-alt" style="margin-top:3px;"></i>
                        <p><?php echo e($configuracion->direccion); ?></p>
                    </div>
                    
                    <div class="item-contact">
                        <i class="fas fa-phone-alt"></i>
                        <p><?php echo e($configuracion->tel); ?></p>
                    </div>
        
                    <div class="item-contact">
                        <i class="fab fa-whatsapp" style="font-size: 20;"></i>
                        <p><?php echo e($configuracion->wsp); ?></p>
                    </div>

                    <div class="item-contact">
                            <i class="fas fa-envelope" style="margin-top:2px;"></i> 
                            <p><?php echo e($configuracion->email); ?></p>
                    </div>
                </div>
        
                <div class="col-12 col-md-8">
                    <div class="row">
                        <div class="col-6">
                            <input class="box" name="nombre" placeholder="Ingresar nombre *" style="margin-bottom:14px;">
                            <input class="box" name="email" placeholder="Ingrese su correo electrónico *">
                        
                        </div>
                
                        <div class="col-6">
                            <input class="box" name="telefono" placeholder="Ingrese tu teléfono *" style="margin-bottom:14px;">
                            <input class="box" name="empresa" placeholder="Empresa">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"> 
                            <textarea class="box" name="mensaje" rows="6" style="padding-top:19px;">Escriba su mensaje...</textarea>
                        </div>
                    </div>
                    <div class="row">
                        


                        <div class="col-1 col-md-9">

                        </div>

                        <div class="col-5 col-md-3">
                            <button type="submite" class="contacto-btn col-3" >
                            ENVIAR 
                            </button>
                        </div>
                    </div>
                </div>

                
            </div>


        </form>   
        
        <?php if(session('info')): ?>
            <script>
                alert("<?php echo e(session('info')); ?>");
            </script>
        <?php endif; ?>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/contacto.blade.php ENDPATH**/ ?>