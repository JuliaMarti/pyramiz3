<div class="form-row">
    <div class="form-group col-md-4">
        <label>Categoria Padre</label>
        <select name="parent_id" class="form-control">
            <option value="">N/A</option>
            <?php echo $__env->make('categories.categories-list', ['categories' => $categories, 'type' => 'select'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </select>
    </div>
    <div class="form-group col-md-4">
        <label>Orden</label>
        <input type="text" name="order" value="<?php echo e(old('order', isset($category) ? $category->order : null )); ?>" class="form-control" placeholder="Order">
    </div>
    <div class="form-group col-md-8">
        <label>Nombre</label>
        <input type="text" name="name" value="<?php echo e(old('order', isset($category) ? $category->name : null )); ?>" class="form-control" placeholder="Nombre">
    </div>
</div>

<div class="form-group">
    <label>Imagen</label>
    <input type="file" accept="image/*" name="image" class="form-control-file">
</div>


<div class="form-check ">
    <input class="form-check-input" type="checkbox" <?php echo e(old('show', isset($category) ? $category->show : null ) == 1 ? 'checked' : ''); ?> name="show" value="1">
    <label class="form-check-label">Mostrar</label>
</div>

<?php if(isset($category)): ?>
    <img src="<?php echo e(asset(Storage::url($category->image))); ?>" style="max-height: 200px; max-width: 200px;" class="img-thumbnail">
<?php endif; ?>
<br>
<br>
<button type="submit" class="btn btn-primary mb-2">Enviar Clase</button><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/categories/form.blade.php ENDPATH**/ ?>