

<?php $__env->startSection('title','Ofertas'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-productos" style="margin-block: 55px;margin-top:42px;">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($itemProducto->show): ?>
                <div class="col-12 col-md-4 item-producto" style="margin-bottom: 37px;">
                    <a href="<?php echo e(route('web.productos.producto',$itemProducto)); ?>" style="text-decoration: none">
                        <div class="box-clase img-active">
                            <div class="img-border-equipo" style="background-image: url(<?php echo e(asset(Storage::url($itemProducto->imagen))); ?>); "></div>
                        </div>
                    </a>
                    
                    <h3><?php echo e($itemProducto->nombre); ?></h3>
                    <p><?php echo e($itemProducto->modelo); ?></p>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>   
    </div>
    
</section>

<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/web/ofertas.blade.php ENDPATH**/ ?>