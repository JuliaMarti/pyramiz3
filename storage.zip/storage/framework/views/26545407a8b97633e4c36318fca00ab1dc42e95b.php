

<?php $__env->startSection('title','Pedidos'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                
                <br>
                <br>
                <div class="card" style="margin-top:15px;">

                    <div class="card-body p-0" >

                        <table class="table">
                            <thead style="color:#03224e"> 
                                <tr>
                                    <th scope="col">Fecha</th>
                                    <th scope="col">Cliente</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Detalle</th>
                                    <th scope="col">Medio de pago</th>
                                    <th scope="col">Envío</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>  

                                <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pedido->created_at); ?></td>
                                    <td><?php echo e($pedido->usuario_nombre); ?></td>
                                    <td><?php echo e($pedido->total); ?></td>
                                    <td>
                                        <?php if($pedido->itemsPedidos): ?>
                                        <ol>

                                        </ol >
                                            <?php $__currentLoopData = $pedido->itemsPedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li style="list-style: none;"> <strong> <?php echo e($item->cantidad); ?>X  </strong><?php echo e($item->nombre); ?> </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-transform: uppercase"><?php echo e($pedido->pago); ?></td>
                                    <td style="text-transform: uppercase"><?php echo e($pedido->envio); ?></td>
                                    <td >
                                        <div style="display:flex; align-items:center">
                                            
                                            <form action="<?php echo e(route('pedidos.destroy', $pedido)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                    
                                            </form>
                                        </div>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot> 
                                <tr>

                                </tr>
                            </tfoot>
                        </table>


                        <?php if(session('info')): ?>
                        <script>
                            alert("<?php echo e(session('info')); ?>");
                        </script>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/pedidos/index.blade.php ENDPATH**/ ?>