

<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-home-categorias" style="margin-bottom: 24px"> 
            
            
            <div class="container">
                <hr style="border: 0.5px solid #000000; margin-bottom:35px;">
                <div class="row">

                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($categoria->home): ?>

                            <div class="col-12 col-md-4" style="margin-bottom:50px ">
                                <div class="img-border-categorias" style="background-image: url(<?php echo e(asset(Storage::url($categoria->imagen))); ?>); "></div>
                                    
                                <div class="text-box-categorias">
                                    <h4><?php echo e($categoria->nombre); ?></h4>
                                </div> 
                                
                            </div>

                            
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>

<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\mundo-hierro\resources\views/web/productos/productos.blade.php ENDPATH**/ ?>