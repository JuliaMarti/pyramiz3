

<?php $__env->startSection('title','CAM CNC'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->

        <div id="carouselExampleIndicators" class="carousel carousel-inicio slide" data-bs-ride="carousel">
            
            <div class="carousel-indicators">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                        <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="carousel-inner">
                    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> ">
                                <img class="d-block w-100" src="<?php echo e(asset(Storage::url($imagen->imagen))); ?>" alt="First slide">
                                <div class="carousel-caption d-none d-md-block">
                                    <h1><?php echo $imagen->parrafo_1; ?></h1>
                                    <p><?php echo $imagen->parrafo_2; ?></p>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
<!--FIN CAROUSEL-INICIO-->


<!--INICIO SECCIÓN EQUIPOS DESTACADOS-->
        <section class="section-equipos-destacados">
            <div class="container">
                <div class="row">
                    <h3 class="col-12">EQUIPOS DESTACADOS</h3>
                </div>

                <div class="row">

                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($producto->show && $producto->destacado): ?>
                        <div class="col-12 col-md-4"  >
                            <div class="img-border-grey" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen_principal))); ?>); ">
                            </div>
                            <p class="nombre-producto" ><?php echo e($producto->name); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
<!--FIN SECCIÓN EQUIPOS DESTACADOS-->        


<!--INICIO SECCIÓN LIBELLUA-->
        <?php if($home->seccion_1_show): ?>
            <section class="section-libellula greyBg">
                <div>
                    <h2><?php echo e($home->seccion_1_titulo); ?></h2>
                    <p><?php echo $home->seccion_1_parrafo; ?></p>
                    <a href="<?php echo e(route('web.productos.producto',$home->producto_id)); ?>" style="text-decoration: none">
                        <div class="borde-info">
                            <p>MÁS INFORMACIÓN</p>
                        </div>
                    </a>    
                </div>
                <img src="<?php echo e(asset(Storage::url($home->seccion_1_imagen))); ?>" alt="">
            </section>
        <?php endif; ?>
<!--FIN SECCIÓN LIBELLUA-->


<!--INICIO SECCIÓN NUESTRA MISIÓN-->
        
        <?php if($home->seccion_2_show): ?>
        
            <section class="section-nuestra-mision">
                
                <div class="container">
                    <h3><?php echo e($home->seccion_2_titulo); ?></h3>
                    <p><?php echo $home->seccion_2_parrafo; ?></p>
                </div>
                
            </section>

        <?php endif; ?>

<!--FIN SECCIÓN NUESTRA MISIÓN-->

        


<!--INICIO SECCIÓN KRRASS-->
        <?php if($home->seccion_3_show): ?>
        <section class="section-krrass"  style="background-image: url(<?php echo e(asset(Storage::url($home->seccion_3_imagen_fondo))); ?>);">
            <img src="<?php echo e(asset(Storage::url($home->seccion_3_imagen))); ?>" alt="">
            <p><?php echo $home->seccion_3_parrafo; ?></p>
            
        </section>
        <?php endif; ?>

<!--FIN SECCIÓN KRRASS-->

<!--INICIO SECCIÓN NUESTROS PRODUCTOS-->        
        <section class="section-nuestros-productos">
            <div class="container">
                <div class="row">
                    <h3>NUESTROS PRODUCTOS</h3>
                </div>

                <div class="row">
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($categoria->show): ?>

                            <div class="col-12 col-md-4">
                                <div class="img-border-grey" style="background-image: url(<?php echo e(asset(Storage::url($categoria->imagen))); ?>); ">
                                </div>
                                <p class="nombre-producto" ><?php echo e($categoria->name); ?></p>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
<!--FIN SECCIÓN NUESTROS PRODUCTOS-->        



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/web/index.blade.php ENDPATH**/ ?>