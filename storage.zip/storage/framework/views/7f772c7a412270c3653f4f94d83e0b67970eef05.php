

<?php $__env->startSection('title','Excel'); ?>

<?php $__env->startSection('content'); ?>

<div class="container cont-empresa">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <form action="<?php echo e(route('excel.import')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>    
                        <div class="form-group">
                            <input type="file" name="archivo" class="form-control-file" >
                        </div>
                        
                        <div class="form-group">
                        <a class="btn btn-info" href="<?php echo e(route('excel.export')); ?>" style="margin-top: 20px; color:white;">Descargar datos</a>
                            <button class="btn btn-success" type="submit">Actualizar DB</button>
                        </div>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/excel/index.blade.php ENDPATH**/ ?>