

<?php $__env->startSection('title', strtoupper($producto->nombre) ); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO PRODUCTO-->


<section class="section-equipo section-categoria" >

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-3">
                <h5 style="font: normal normal bold 15px/60px Montserrat;letter-spacing: 0px;color: #000000; border-bottom: 2px solid #000000; height:45px;"> CATEGORÍAS</h5>
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', $item->id)); ?>" class="  <?php echo e($categoria_id == $item->id ? 'cat-activa' : 'cat-no-activa'); ?>  list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item2->show && $item->id == $item2->categoria_id ): ?>
                            <a  href="<?php echo e(route('web.productos.producto',$item2)); ?>" class="<?php echo e($producto->id == $item2->id  ? 'prod-activo' : 'prod-no-activo '); ?> list-group-item list-group-item-action list-trabajo" style=" padding-left:35px;" ><?php echo e($item2->nombre); ?></a>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-home-categorias col-9"> 
                <div class="container" style="padding-left:3px">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div>
                                <div class="img-trabajo" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen))); ?>); ">
                                    <?php if(!$producto->hay_stock): ?>
                                        <div class="ribbon ribbon-top-left sin_stock"><span style="    background-color: #6c757d;">SIN STOCK</span></div>
                                    <?php else: ?> 
                                        <?php if($producto->oferta): ?>
                                            <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            

                        </div>
                        <div class="col-12 col-md-6" style="display: flex; flex-direction:column; justify-content:space-between;">
                            <div>
                                <div class="tabla-trabajo" style="font: normal normal bold 25px/29px Montserrat;color: #000000;">
                                    <?php echo e($producto->nombre); ?>

                                </div>
                                
                                <p class="precio" style=" font: normal normal bold 31px/42px Montserrat;">
                                    <?php if($producto->oferta && $producto->hay_stock): ?>
                                    <span class="precio-oferta" style="font: normal normal medium 18px/42px Montserrat; margin-right:19px;">$<?php echo e($producto->tprecio_anterior); ?></span>
                                    <?php endif; ?>
                                    
                                    $<?php echo e($producto->tprecio); ?>


                                </p>

                                <div class="descripcion" style="margin-bottom:25px;"> <?php echo $producto->descripcion; ?> </div>

                                <div>

                                    <div style="display: flex; font: normal normal normal 14px/17px Montserrat; font-weight:500 ; color: #333333; margin-bottom:15px;"> <p style="width: 175px; margin-right: 22px;"> </p><img src="http://www.gasessanmartin.com.ar/img/installments.png" style="width: 280px; height: 37px;"></div>
                                    
                                   
                                    <div class="row" style="">
                                        <div style="margin-left: 15px; padding: 5px;max-width: 293px;">

                                        <p style="color: black; font-size: 14px;line-height: 0.4"><img src="http://www.gasessanmartin.com.ar/img/dolar.svg"> Transferencia Bancaria o Depósito</p>
                                        <p style="color: black; font-size: 14px;margin-bottom: 0px;line-height: 0.4"> <img src="http://www.gasessanmartin.com.ar/img/money.svg">  Calcular costos de envíos</p>

                                        
                                        </div>
                                    </div>
                                        
                                        <?php if($producto->hay_stock): ?>
                                            <add-to-cart unit="<?php echo e($producto->unidad_de_venta ?? 1); ?>"
                                                price="<?php echo e($producto->precio); ?>"
                                                nombre="<?php echo e($producto->nombre); ?>"
                                                imagen="<?php echo e($producto->imagen_url); ?>"
                                                id="<?php echo e($producto->id); ?>"
                                                ref="me"
                                            /> 
                                        <?php endif; ?>
                                    
                                </div>
                            </div>

                        </div>
                    </div>
                
                    <div class="row" style="margin-bottom:35px;">
                        <h5 style="font: normal normal 600 17px/52px Montserrat;color: #2B1C17; border-bottom: 1px solid #BFBFBF; margin-left: calc(var(--bs-gutter-x)/ 2);">Especificaciones</h5>
                        <div class="especificaciones"><?php echo $producto->tabla; ?></div>
                    </div>

                    <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); display:flex; justify-content:center;">
                        <div  class="col-12">
                            <h5 style="font: normal normal 600 16px/25px Montserrat;
                            letter-spacing: 0.29px;
                            text-align:center;
                            color: #2B1C17;
                            margin-bottom:0;">Productos relacionados</h5>
                            
                            <hr style="width: 50px;
                            border: 1px solid #DA241D;
                            opacity:1;
                            margin-left: auto;
                            margin-right: auto;
                            margin-top:5px;
                            margin-bottom:25px;">
                        </div>

                        <?php if($relacionado_1): ?>
                            <?php if($relacionado_1->show): ?>
                                <?php if($relacionado_1->oferta): ?>
                                    <div class="col-12 col-md-4" >
                                        <a href="<?php echo e(route('web.productos.producto',$relacionado_1)); ?>" style="text-decoration: none">
                                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_1->imagen))); ?>); ">
                                            <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                        </div>
                                            
                                        <div class="text-box-categorias">
                                            <h4><?php echo e($relacionado_1->nombre); ?></h4>
                                            <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($relacionado_1->tprecio_anterior); ?></span>$<?php echo e($relacionado_1->tprecio); ?></p>
                                        </div> 
                                        </a>
                                        
                                    </div>

                                <?php else: ?>
                                    <div class="col-12 col-md-4" >
                                        <a href="<?php echo e(route('web.productos.producto',$relacionado_1)); ?>" style="text-decoration: none">
                                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_1->imagen))); ?>); "></div>
                                                
                                            <div class="text-box-categorias">
                                                <h4><?php echo e($relacionado_1->nombre); ?></h4>
                                                <p class="precio" style="text-align: right;">$<?php echo e($relacionado_1->tprecio); ?></p>
                                            </div> 
                                        </a>
                                    </div>   
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if($relacionado_2): ?>
                            <?php if($relacionado_2->show): ?>
                                <?php if($relacionado_2->oferta): ?>
                                    <div class="col-12 col-md-4" >
                                        <a href="<?php echo e(route('web.productos.producto',$relacionado_2)); ?>" style="text-decoration: none">
                                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_2->imagen))); ?>); ">
                                            <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                        </div>
                                            
                                        <div class="text-box-categorias">
                                            <h4><?php echo e($relacionado_2->nombre); ?></h4>
                                            <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($relacionado_2->tprecio_anterior); ?></span>$<?php echo e($relacionado_2->tprecio); ?></p>
                                        </div> 
                                        </a>
                                        
                                    </div>

                                <?php else: ?>
                                    <div class="col-12 col-md-4" >
                                        <a href="<?php echo e(route('web.productos.producto',$relacionado_2)); ?>" style="text-decoration: none">
                                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_2->imagen))); ?>); "></div>
                                                
                                            <div class="text-box-categorias">
                                                <h4><?php echo e($relacionado_2->nombre); ?></h4>
                                                <p class="precio" style="text-align: right;">$<?php echo e($relacionado_2->tprecio); ?></p>
                                            </div> 
                                        </a>
                                    </div>   
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if($relacionado_3): ?>
                            <?php if($relacionado_3->show): ?>
                                <?php if($relacionado_3->oferta): ?>
                                    <div class="col-12 col-md-4" >
                                        <a href="<?php echo e(route('web.productos.producto',$relacionado_3)); ?>" style="text-decoration: none">
                                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_3->imagen))); ?>); ">
                                            <div class="ribbon ribbon-top-left"><span>¡OFERTA!</span></div>
                                        </div>
                                            
                                        <div class="text-box-categorias">
                                            <h4><?php echo e($relacionado_3->nombre); ?></h4>
                                            <p class="precio" style="text-align: center;"><span class="precio-oferta">$<?php echo e($relacionado_3->tprecio_anterior); ?></span>$<?php echo e($relacionado_3->tprecio); ?></p>
                                        </div> 
                                        </a>
                                        
                                    </div>

                                <?php else: ?>
                                    <div class="col-12 col-md-4" >
                                        <a href="<?php echo e(route('web.productos.producto',$relacionado_3)); ?>" style="text-decoration: none">
                                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_3->imagen))); ?>); "></div>
                                                
                                            <div class="text-box-categorias">
                                                <h4><?php echo e($relacionado_3->nombre); ?></h4>
                                                <p class="precio" style="text-align: right;">$<?php echo e($relacionado_3->tprecio); ?></p>
                                            </div> 
                                        </a>
                                    </div>   
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>

                </div>
            </section>
        </div>
    </div>

</section>



<!--FIN PRODUCTO-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?> 
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    window.colores = <?php echo $producto->galerias; ?>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/productos/producto.blade.php ENDPATH**/ ?>