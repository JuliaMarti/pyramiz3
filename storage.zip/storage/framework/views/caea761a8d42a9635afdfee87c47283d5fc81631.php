

<?php $__env->startSection('title',strtoupper($categoria->nombre)); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-categoria" style="margin-bottom:65px">

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-2">
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', $item->id)); ?>" style="<?php echo e($categoria_id == $item->id ? 'background-color:#E8E8E8; color: #726D6E;' : 'color: #C7D52B;'); ?>" class="list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item2->show && $item->id == $item2->categoria_id ): ?>
                            <a  href="<?php echo e(route('web.productos.producto',$item2)); ?>" class="list-group-item list-group-item-action list-trabajo" style="<?php echo e(false ? 'background-color:#E8E8E8; color: #726D6E;' : 'color: #C7D52B; '); ?> padding-left:35px;" ><?php echo e($item2->nombre); ?></a>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-home-categorias col-10" style="margin-bottom: 24px"> 
                <div class="container">
                    <div class="row">

                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                                <?php if($item->show): ?>
                                <div class="col-12 col-md-4" style="margin-bottom:50px ">
                                    <a href="<?php echo e(route('web.productos.producto',$item)); ?>" style="text-decoration: none">
                                    <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); "></div>
                                        
                                    <div class="text-box-categorias">
                                        <h4><?php echo e($item->nombre); ?></h4>
                                    </div> 
                                    </a>
                                    
                                </div>
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    </div>
                </div>
            </section>
        </div>
    </div>

</section>
<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/productos/categoria.blade.php ENDPATH**/ ?>