

<?php $__env->startSection('title','Categorías'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
                <button type="button" class="btn btn-success" style="float:right;"><a style ="color:white;" href="<?php echo e(route('categorias.create')); ?>"><i class="fas fa-plus" style ="color:white; margin-right:7px;" ></i>AÑARDIR</a></button>
                <br>
                <br>
                <div class="card" style="margin-top:15px;">

                    <div class="card-body p-0" >

                        <table class="table">
                            <thead style="color:#03224e"> 
                                <tr>
                                    <th scope="col">Imagen</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Mostrar</th>
                                    <th scope="col">Orden</th>
                                    <th scope="col">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>  

                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <img src="<?php echo e(asset(Storage::url($categoria->imagen))); ?>" style="height:60px;"></td>
                                    <td><?php echo e($categoria->name); ?></td>
                                    <td><?php echo e($categoria->show ? 'Si' : 'No'); ?></td>
                                    <td><?php echo e($categoria->orden); ?></td>
                                    <td style="display:flex;">
                                        <button type="button" class="btn btn-primary" style="margin-right:5px;"><a style ="color:white;"href="<?php echo e(route('categorias.edit',$categoria)); ?>"><i class="far fa-edit"></i></a></button>
                                        <form action="<?php echo e(route('categorias.destroy', $categoria)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submite" class="btn btn-danger"><a style ="color:white;"href="#"><i class="fas fa-trash-alt"></i></a></button>
                                
                                        </form>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                            <tfoot> 
                                <tr>

                                </tr>
                            </tfoot>
                        </table>

                        <?php if(session('info')): ?>
                        <script>
                            alert("<?php echo e(session('info')); ?>");
                        </script>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/categorias/index.blade.php ENDPATH**/ ?>