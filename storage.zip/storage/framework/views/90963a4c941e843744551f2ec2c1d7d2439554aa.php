

<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN PRODUCTOS-->        

<section class="section-productos">
    <div class="container">

    <?php if(count($categorias) != 0): ?>
        <div class="row" style="margin-top: 22px; margin-bottom:64px;">
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($itemCategoria->show): ?>
                    <div class="col-12 col-md-4" style="margin-bottom: 37px;">
                        <a href="<?php echo e(route('web.productos.categoria',$itemCategoria)); ?>" style="text-decoration: none">
                            <div class="box-clase">
                                <div class="img-border-equipos" style="background-image: url(<?php echo e(asset(Storage::url($itemCategoria->image))); ?>); "></div>
                                <p class="nombre-clase"><?php echo e($itemCategoria->name); ?></p>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
    <div class="row" style="margin-top: 22px; margin-bottom:64px;">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemProducto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($itemProducto->show): ?>
                <div class="col-12 col-md-4 item-producto" style="margin-bottom: 37px;">
                    <a href="<?php echo e(route('web.productos.producto',$itemProducto)); ?>" style="text-decoration: none">
                        <div class="box-clase img-active">
                            <div class="img-border-equipo" style="background-image: url(<?php echo e(asset(Storage::url($itemProducto->imagen))); ?>); "></div>
                        </div>
                    </a>
                    
                    <h3><?php echo e($itemProducto->nombre); ?></h3>
                    <p><?php echo e($itemProducto->modelo); ?></p>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
        
    </div>
    
</section>

<!--FIN SECCIÓN PRODUCTOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/web/productos/categoria.blade.php ENDPATH**/ ?>