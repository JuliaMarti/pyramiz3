

<?php $__env->startSection('title','Contacto'); ?>

<?php $__env->startSection('content'); ?>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3280.8501345328723!2d-58.41854558519235!3d-34.68373166924234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccc8a38d8cf11%3A0x17279d842436377c!2sCAM%20CNC%20%7C%20Pantografos!5e0!3m2!1ses!2sar!4v1617200960245!5m2!1ses!2sar" width="100%" height="332" style="border:0;" allowfullscreen="" loading="lazy"></iframe>

<section class="section-contacto">
    <div class="container">
        
        <form method="POST" action="<?php echo e(route('web.contactanos')); ?>"> 
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-4">
                    <h3 >CONTACTO</h3>
                    <hr style="border: 1px solid #000000; margin-bottom:25px;">

                    <div class="item-contact">
                        <i class="fas fa-map-marker-alt" style="margin-top:3px;"></i>
                        <p><?php echo e($configuracion->direccion); ?></p>
                    </div>
                    
                    <div class="item-contact">
                        <i class="fas fa-phone-alt"></i>
                        <p><?php echo e($configuracion->tel); ?></p>
                    </div>
        
                    <div class="item-contact">
                        <i class="fab fa-whatsapp" style="font-size: 24;"></i>
                        <p><?php echo e($configuracion->wsp); ?></p>
                    </div>

                    <div class="item-contact">
                            <i class="fas fa-envelope" style="margin-top:2px;"></i> 
                            <p><?php echo e($configuracion->email); ?></p>
                    </div>
                </div>
        
                <div class="col-8">
                    <div class="row">
                        <div class="col-6">
                            <input class="box" name="nombre" placeholder="Ingresar nombre *" style="margin-bottom:14px;">
                            <input class="box" name="email" placeholder="Ingrese su correo electrónico *">
                        
                        </div>
                
                        <div class="col-6">
                            <input class="box" name="telefono" placeholder="Ingrese tu teléfono *" style="margin-bottom:14px;">
                            <input class="box" name="empresa" placeholder="Empresa">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12"> 
                            <textarea class="box" name="mensaje" rows="6" style="padding-top:19px;">Escriba su mensaje...</textarea>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <a href="#" style="text-decoration: none">
                                <div  class="input-descarga " >
                                <span>Examinar Archivo</span>
                                <span>...</span>
                                </div>
                            </a>
                        </div>

                        <div class="col-3">

                        </div>

                        <div class="col-3">
                            <button type="submite" class="contacto-btn col-3" >
                            ENVIAR <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </div>
                </div>

                
            </div>


        </form>   
        
        <?php if(session('info')): ?>
            <script>
                alert("<?php echo e(session('info')); ?>");
            </script>
        <?php endif; ?>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\mundo-hierro\resources\views/web/contacto.blade.php ENDPATH**/ ?>