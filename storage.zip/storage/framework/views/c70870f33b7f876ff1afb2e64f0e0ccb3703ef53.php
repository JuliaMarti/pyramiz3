

<?php $__env->startSection('title','Post Venta'); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO BLOG-->


<section class="section-blog-noticia"> 
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-8">
                <h4><?php echo e($noticia->categoria->nombre); ?></h4>
                <h5><?php echo e($noticia->titulo); ?></h5>
                <div class="img-border-noticia" style="background-image: url(<?php echo e(asset(Storage::url($noticia->imagen))); ?>); ">
                </div>
                <p><?php echo $noticia->caracteristicas; ?></p>
            </div>

            <div class="col-12 col-md-4 blog-nav">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item ul-title">Blog</li>
                    <li class="list-group-item"><a href="<?php echo e(route('web.blogs','todas')); ?>" style="text-decoration: none">TODAS<span>><span></a></li>
                    <?php $__currentLoopData = $claseblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claseblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item"><a href="<?php echo e(route('web.blogs',$claseblog->id)); ?>" style="text-decoration: none"><?php echo e($claseblog->nombre); ?><span>><span></a></li>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

    </div>

</section>



<!--FIN BLOG-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/web/blogs/noticia.blade.php ENDPATH**/ ?>