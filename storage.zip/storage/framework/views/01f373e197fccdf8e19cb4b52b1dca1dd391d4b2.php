

<?php $__env->startSection('title','Red social nueva'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('redes.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de categorías de noticias</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('redes.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Elige una red social</label>
                                    <select class="form-control" name="icono">
                                        <option disabled>Elige una red social...</option>
                                        <option <?php echo e(old('icono') == '<i class="fab fa-instagram"></i>' ? 'selected' : ''); ?> value='<i class="fab fa-instagram"></i>'>Instagram</option>
                                        <option <?php echo e(old('icono') == '<i class="fab fa-twitter"></i>' ? 'selected' : ''); ?> value='<i class="fab fa-twitter"></i>'>Twitter</option>
                                        <option <?php echo e(old('icono') == '<i class="fab fa-facebook-f"></i>' ? 'selected' : ''); ?> value='<i class="fab fa-facebook-f"></i>'>Facebook</option>
                                        <option <?php echo e(old('icono') == '<i class="fab fa-youtube"></i>' ? 'selected' : ''); ?> value='<i class="fab fa-youtube"></i>'>YouTube</option>
                                        <option <?php echo e(old('icono') == '<i class="fab fa-linkedin-in"></i>' ? 'selected' : ''); ?> value='<i class="fab fa-linkedin-in"></i>'>LinkedIn</option>
                                        <option <?php echo e(old('icono') == '<i class="fab fa-telegram-plane"></i>' ? 'selected' : ''); ?> value='<i class="fab fa-telegram-plane"></i>'>LinkedIn</option>

                                    </select>


                                </div>
                            
                                <div class="form-group col-md-4">
                                    <label>URL</label>
                                    <input type="text" name="url" value="<?php echo e(old('url')); ?>" class="form-control" placeholder="URL">
                                </div>
                            </div>

                            

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>
                            <br>

                            <button type="submit" class="btn btn-primary mb-2">Enviar red social</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/redes/create.blade.php ENDPATH**/ ?>