

<?php $__env->startSection('title','Modificar Foto'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('show_productos.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de productos</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('galeriasP.update', $galeria)); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                                <div class="form-group col-md-3">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden', $galeria->orden)); ?>" class="form-control" placeholder="Orden">
                                </div>

                                <div class="form-group">
                                    <label>Imagen</label>
                                    <input type="file" accept="image/*" name="imagen" value="<?php echo e(old('imagen', $galeria->imagen)); ?>" class="form-control-file" >
                                </div>

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show', $galeria->show) == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>
                            <br>

                            <button type="submit" class="btn btn-primary mb-2">Actualizar foto</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/galerias_p/edit.blade.php ENDPATH**/ ?>