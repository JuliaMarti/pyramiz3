

<?php $__env->startSection('title','Empresa'); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO CAROUSEL-EMPRESA-->

<div id="Cempresa" class="carousel carousel-empresa slide d-none d-md-flex" data-bs-ride="carousel">
    
    <div class="fondo"></div>

    <div class="carousel-indicators" style="z-index: 999;">
        <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                    <button type="button" data-bs-target="#Cempresa" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="carousel-inner">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> ">
                        <div class="img" style="background-image: url(<?php echo e(asset(Storage::url($imagen->imagen))); ?>)"></div>
                        <div class="carousel-caption d-none d-md-block carousel-texto">
                            <h2><?php echo e($imagen->titulo); ?></h2>
                            <h3><?php echo e($imagen->subtitulo); ?></h3>

                            <p><?php echo e($imagen->texto); ?></p>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<!--FIN CAROUSEL-EMPRESA-->

            <section class="section-empresa ">
                <hr>
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <h3>NUESTRA EMPRESA</h3>
                            <?php echo $empresa->parrafo; ?>

                            
                        </div>
                        <div class="col-12 col-md-6 imagen-empresa"  style="background-image: url(<?php echo e(asset(Storage::url($empresa->imagen))); ?>); "></div>
                    </div>
                </div>
            </section>


<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\mundo-hierro\resources\views/web/empresa.blade.php ENDPATH**/ ?>