<?php if($type == 'list-group'): ?>
    <div class="list-group">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="list-group-item">
                <?php echo e($cat->name); ?>

                <div class="btn-group">
                    <a href="<?php echo e(route('categories.edit', $cat)); ?>" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                    <a href="<?php echo e(route('categories.destroy', $cat)); ?>" class="btn btn-danger"><i class="fas fa-trash"></i></a>
                </div>
            </div>
            <?php if($cat->categories()->count()): ?>
                <div class="list-group-item">
                    <?php echo $__env->make('categories.categories-list', ['categories' => $cat->categories, 'type' => 'list-group'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php if($type == 'select'): ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cat->id); ?>" <?php echo e($cat->id == old('parent_id', isset($category) ? $category->parent_id : null ) ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
            <?php if($cat->categories()->count()): ?>
                <optgroup label="<?php echo e($cat->name); ?>">
                    <?php echo $__env->make('categories.categories-list', ['categories' => $cat->categories, 'type' => 'select'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </optgroup>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/categories/categories-list.blade.php ENDPATH**/ ?>