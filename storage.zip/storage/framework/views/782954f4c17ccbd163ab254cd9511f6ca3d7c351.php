

<?php $__env->startSection('title','Nuevo producto'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('show_productos.index')); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al listado de productos</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('productos.store')); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden')); ?>" class="form-control" placeholder="Orden">
                                </div>
                                <div class="form-group col-md-4">
                                    <label>Nombre</label>
                                    <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control" placeholder="Nombre">
                                </div>

                                <div class="form-group col-md-4">
                                    <label>Elige una categoría para el equipo</label>
                                    <select class="form-control" name="categoria_id">
                                        <option disabled>Elige una categoría...</option>
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(old('categoria_id') == $categoria->id ? 'selected' : ''); ?> value="<?php echo e($categoria->id); ?>"> <?php echo e($categoria->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            

                            <div class="form-group">
                                <label>Imagen </label>
                                <input type="file" accept="image/*" name="imagen" value="<?php echo e(old('imagen')); ?>" class="form-control-file" >
                            </div>


                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show') == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>
                            <br>


                            <div class="form-group ">
                                <label>Presentación</label>
                                <textarea class="form-control" name="presentacion"  rows="3"><?php echo e(old('presentacion')); ?></textarea>
                            </div>

                            <div class="form-group ">
                                <label>Normas</label>
                                <textarea class="form-control" name="normas"  rows="3"><?php echo e(old('normas')); ?></textarea>
                            </div>

                            <div class="form-group ">
                                <label>Descripción</label>
                                <textarea class="form-control summernote" name="descripcion" ><?php echo e(old('descripcion')); ?></textarea>
                            </div>

                            <h4>Gráfico</h4>
                            <hr>
                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('imagen_grafico') == 1 ? 'checked' : ''); ?> name="imagen_grafico" value="1">
                                <label class="form-check-label">Mostrar Imagen gráfico</label>
                            </div>

                            <div class="form-group">
                                <label>Imagen del gráfico</label>
                                <input type="file" accept="image/*" name="imagen_grafico" value="<?php echo e(old('imagen_grafico')); ?>" class="form-control-file" >
                            </div>


                            <hr>

                            <div class="form-group">
                                <label>Ficha técnica</label>
                                <input type="file" accept="image/*" name="ficha_tecnica" value="<?php echo e(old('ficha_tecnica')); ?>" class="form-control-file" >
                            </div>

                            <h4>Medidas</h4>
                            <hr>

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show_medidas') == 1 ? 'checked' : ''); ?> name="show_medidas" value="1">
                                <label class="form-check-label">Mostrar medidas</label>
                            </div>

                            <div class="form-group ">
                                <label>Espesor</label>
                                <textarea class="form-control summernote" name="espesor" ><?php echo e(old('espesor')); ?></textarea>
                            </div>
                            <div class="form-group ">
                                <label>Largo</label>
                                <textarea class="form-control summernote" name="largo" ><?php echo e(old('largo')); ?></textarea>
                            </div>
                            <div class="form-group ">
                                <label>Ancho</label>
                                <textarea class="form-control summernote" name="ancho" ><?php echo e(old('ancho')); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary mb-2">Enviar producto</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mundo-hierro\resources\views/productos/create.blade.php ENDPATH**/ ?>