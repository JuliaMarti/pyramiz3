<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <p>Nombre: <?php echo e($info['nombre']); ?></p>
    <p>Apellido: <?php echo e($info['apellido']); ?></p>
    <p>Email: <?php echo e($info['email']); ?></p>
    <p>Razon Social: <?php echo e($info['razon_social']); ?></p>
    <p>Direccion: <?php echo e($info['direccion']); ?></p>
    <p>Teléfono: <?php echo e($info['telefono']); ?></p>

    <br>

    <p>Ancho útil de corte requerido: <?php echo e($info['ancho_util']); ?> mm</p>
    <p>Largo útil de corte requerido: <?php echo e($info['largo_util']); ?> mm</p>

    <br>

    <p>Espesor de corte:</p>
    <ul>
        <li>Mínimo: <?php echo e($info['minimo']); ?></li>
        <li>Máximo: <?php echo e($info['maximo']); ?></li>
    </ul>

    <p>Material a cortar:</p>
    <ul>
        <?php if(array_key_exists('acero_inoxidable',$info)): ?>
            <li>Acero inoxidable: Si</li>
        <?php endif; ?>

        <?php if(array_key_exists('acero_al_carbono',$info)): ?> 
            <li>Acero al carbono: Si</li>
        <?php endif; ?>

        <?php if(array_key_exists('aluminio',$info)): ?> 
            <li>Aluminio: Si</li>
        <?php endif; ?>

        <?php if(array_key_exists('galvanizado',$info)): ?> 
            <li>Galvanizado: Si</li>
        <?php endif; ?>

    </ul>

    <br>

    <p>Comentarios: </p>
    <p><?php echo e($info['comentarios']); ?></p>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/emails/presupuesto.blade.php ENDPATH**/ ?>