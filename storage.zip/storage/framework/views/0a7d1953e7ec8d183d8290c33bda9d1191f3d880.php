

<?php $__env->startSection('title','Equipos'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-nuestros-productos">
    <div class="container">

        <div class="row">
            
            <form method="GET" action="<?php echo e(route('web.equipos.buscar')); ?>">
                <div class="row"> 
                        <div class="form-check col-6 col-md">
                            <input class="form-check-input" name="en_venta" type="checkbox" id="enVenta" <?php echo e($en_venta ? 'checked' : ""); ?>>
                            <label class="form-check-label" for="enVenta">
                            EN VENTA
                            </label>
                        </div>
        
                        <div class="form-check col-6 col-md">
                            <input class="form-check-input" name="en_alquiler" type="checkbox" id="enAlquiler" <?php echo e($en_alquiler ? 'checked' : ""); ?>>
                            <label class="form-check-label" for="enAlquiler">
                            EN ALQUILER
                            </label>
                        </div>
        
                        <div class="mb-3 col-12 col-md-2">
                            <select class="form-control" name="clase_id" id="claseEquipo">
                                <option value="" selected disabled>CLASE</option>
                                <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemClase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('clase_id') == $itemClase->id ? 'selected' : ''); ?> value="<?php echo e($itemClase->id); ?>"> <?php echo e($itemClase->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
        
                        <div class="mb-3 col-12 col-md-3">
                            <select class="form-control" name="altura_id">
                                <option value="" selected disabled>ALTURA DE TRABAJO</option>
                                <?php $__currentLoopData = $alturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('altura_id') == $altura->id ? 'selected' : ''); ?> value="<?php echo e($altura->id); ?>"> <?php echo e($altura->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
        
                        <div class="mb-3 col-12 col-md-3">
                            <select class="form-control" name="combustion_id">
                                <option value="" selected disabled>TIPO DE COMBUSTIÓN</option>
                                <?php $__currentLoopData = $combustiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $combustion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(old('combustion_id') == $combustion->id ? 'selected' : ''); ?> value="<?php echo e($combustion->id); ?>"> <?php echo e($combustion->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <button type="submit" class="mb-3 col btn-equipo-izquierda">BUSCAR</button>
                </div>
            </form>
        </div>
        <div class="row" style="margin-top: 22px; margin-bottom:64px;">
            <?php if($clase): ?>
            <div class="col-12 descripcion-clase">
                <h3><?php echo e($clase->nombre); ?></h3>
                <p><?php echo e($clase->descripcion); ?></p>
            </div>
            <?php endif; ?>


            <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($equipo->show): ?>

                    <?php if($en_venta && $en_alquiler): ?>
                        <?php if($equipo->en_venta && $equipo->en_alquiler): ?>
                            <div class="col-12 col-md-4 item-producto" style="margin-bottom: 37px;">
                                <a href="<?php echo e(route('web.equipos.equipo',$equipo)); ?>" style="text-decoration: none">
                                    <div class="box-clase img-active">
                                        <div class="img-border-equipo" style="background-image: url(<?php echo e(asset(Storage::url($equipo->imagen_general))); ?>); "></div>
                                    </div>
                                </a>                           
                                <h3><?php echo e($equipo->nombre); ?></h3>
                                <p><?php echo e($equipo->modelo); ?></p>
                            </div>
                        <?php endif; ?>    
                    <?php else: ?> <?php if($en_venta): ?>
                        <?php if($equipo->en_venta): ?>
                            <div class="col-12 col-md-4 item-producto" style="margin-bottom: 37px;">
                                <a href="<?php echo e(route('web.equipos.equipo',$equipo)); ?>" style="text-decoration: none">
                                    <div class="box-clase img-active">
                                        <div class="img-border-equipo" style="background-image: url(<?php echo e(asset(Storage::url($equipo->imagen_general))); ?>); "></div>
                                    </div>
                                </a>                           
                                <h3><?php echo e($equipo->nombre); ?></h3>
                                <p><?php echo e($equipo->modelo); ?></p>
                            </div>
                        <?php endif; ?>  
                    <?php else: ?> <?php if($en_alquiler): ?>
                        <?php if($equipo->en_alquiler): ?>
                            <div class="col-12 col-md-4 item-producto" style="margin-bottom: 37px;">
                                <a href="<?php echo e(route('web.equipos.equipo',$equipo)); ?>" style="text-decoration: none">
                                    <div class="box-clase img-active">
                                        <div class="img-border-equipo" style="background-image: url(<?php echo e(asset(Storage::url($equipo->imagen_general))); ?>); "></div>
                                    </div>
                                </a>                           
                                <h3><?php echo e($equipo->nombre); ?></h3>
                                <p><?php echo e($equipo->modelo); ?></p>
                            </div>
                        <?php endif; ?>      
                    <?php else: ?>
                        <div class="col-12 col-md-4 item-producto" style="margin-bottom: 37px;">
                            <a href="<?php echo e(route('web.equipos.equipo',$equipo)); ?>" style="text-decoration: none">
                                <div class="box-clase img-active">
                                    <div class="img-border-equipo" style="background-image: url(<?php echo e(asset(Storage::url($equipo->imagen_general))); ?>); "></div>
                                </div>
                            </a>                           
                            <h3><?php echo e($equipo->nombre); ?></h3>
                            <p><?php echo e($equipo->modelo); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section>

<!--FIN SECCIÓN EQUIPOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pyramiz3\resources\views/web/equipos/clase.blade.php ENDPATH**/ ?>