

<?php $__env->startSection('title','Configuración de los Pedidos'); ?>

<?php $__env->startSection('content'); ?>


<div class="container cont-configpedido">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>


                    <?php $configpedido = $configpedidos->first() ?>
            
                        
                    <form action="<?php echo e(route('configpedidos.update',$configpedido)); ?>" enctype="multipart/form-data" method="POST">
                                
                        <?php echo csrf_field(); ?>
                        
                        <?php echo method_field('put'); ?>
                        
                        <h3>Envios</h3>
                        <div class="form-group">
                            <label>RETIRO POR EL LOCAL </label>
                            <textarea class="form-control summernote" name="envio_local" rows="3"><?php echo e(old('envio_local',$configpedido->envio_local)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>EXPRESO A CARGO DEL COMPRADOR</label>
                            <textarea class="form-control summernote" name="envio_comprador" rows="3"><?php echo e(old('envio_comprador',$configpedido->envio_comprador)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>ENVIO A CABA</label>
                            <textarea class="form-control summernote" name="envio_caba" rows="3"><?php echo e(old('envio_caba',$configpedido->envio_caba)); ?></textarea>
                        </div>

                        <hr>
                        <h3>Descuentos por sistema de pago (en porcentaje)</h3>
                        
                        <div class="form-group col-md-6">
                            <label>TARJETA DE DÉBITO / CRÉDITO</label>
                            <input type="number" min="0" name="descuento_tarjeta" value="<?php echo e(old('descuento_tarjeta', $configpedido->descuento_tarjeta)); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <textarea class="form-control summernote" name="parrafo_tarjeta" rows="3"><?php echo e(old('parrafo_tarjeta',$configpedido->parrafo_tarjeta)); ?></textarea>
                        </div>





                        <div class="form-group col-md-6">
                            <label>TRANSFERENCIA BANCARIA</label>
                            <input type="number" min="0" name="descuento_transferencia" value="<?php echo e(old('descuento_transferencia', $configpedido->descuento_transferencia)); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <textarea class="form-control summernote" name="parrafo_transferencia" rows="3"><?php echo e(old('parrafo_transferencia',$configpedido->parrafo_transferencia)); ?></textarea>
                        </div>





                        <div class="form-group col-md-6">
                            <label>PAGO EN LOCAL</label>
                            <input type="number" min="0" name="descuento_local" value="<?php echo e(old('descuento_local', $configpedido->descuento_local)); ?>" class="form-control">
                        </div>

                        <div class="form-group">
                            <textarea class="form-control summernote" name="parrafo_local" rows="3"><?php echo e(old('parrafo_local',$configpedido->parrafo_local)); ?></textarea>
                        </div>






                        <button type="submit" class="btn btn-primary mb-2" >Actualizar Configuración</button>
                    </form>
                    <?php if(session('info')): ?>
                    <script>
                        alert("<?php echo e(session('info')); ?>");
                    </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/configpedidos/index.blade.php ENDPATH**/ ?>