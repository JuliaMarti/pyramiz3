<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $__env->yieldContent('title'); ?></title>
    

    <!-- Bootstrap -->
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <!-- JavaScript Bundle with Popper -->
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;1,300;1,400;1,500&display=swap" rel="stylesheet">
    
    <!-- CSS -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    
    
    <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>



    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    </head>

    <body>
        <div id="app">
<!--INICIO HEADER-->


        <header>
                <div class=" header-top  ">
                    <div class="container" style="display: flex; justify-content: space-between;">
                            <div class="fondo header-top-box d-none d-md-flex header-top-contacto col-md-5" >
                            
                                
                                <div class="item-header " style="margin-right:5px">
                                    <i class="fas fa-phone-alt" style="margin-right:12px; font-size:12px;"></i>
                                <?php echo $configuracion->tel; ?>   <span style="margin-left:7px;">|</span>
                                </div>   

                                <div class="header-top-box" style=" padding-bottom:8px; padding-top:8px; ">
                                    <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="header-top-item " style=" padding: 4px 3px 4px 3px; ">
                                            <a href="<?php echo e($red->url); ?>" <?php echo e($red->url ? 'target=”_blank”' : ''); ?>  ><?php echo $red->icono; ?></a>         
                                        </div>                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                                
                            </div>

                            <a href="<?php echo e(route('web.home')); ?>" class="col-8 col-md-2" style="display: flex; justify-content:center;">
                                <img src="<?php echo e(asset(Storage::url($home->logo))); ?>"  alt="Qunuy" style="width: 62%;">
                            </a>

                            <div class="col-md-5" style="display: flex; align-items:center; justify-content: flex-end; ">
                                <ul class="nav-usuario d-none d-md-flex" style="list-style: none" >
                                    
                                    
                                    <li class="buscador" style="position: relative; margin-right:15px; justify-content:flex-end;">
                                        <form method="GET" action="<?php echo e(route('web.busqueda')); ?>"> 
                                            <?php echo csrf_field(); ?>
                                            
                                            <input type="text" placeholder="Buscar..." name="busqueda">
    
                                            <button type="submit" > <i class="fas fa-search"></i> </button>
                                        </form>
                                    </li>
                                    
                                    <?php if(auth()->guard('usuario')->check()): ?>
                                    <li class="nav-item" style="color:white; padding-left:15px; display: flex; align-items: center;">
                                        Hola, <?php echo e(auth()->guard('usuario')->user()->nombre); ?>   
                                    </li>  
                                    <li class="nav-item " style="display: flex; align-items: center;">
                                        <a class="nav-link" href="<?php echo e(route('web.clientes.logout')); ?>" style="padding:0; font-size:13px; padding-left:15px;"><span>Salir</span></a>
                                    </li> 
                                    <?php else: ?>
                                    <li class="nav-item" >
                                        <a class="nav-link" href="<?php echo e(route('web.clientes')); ?>"><img src="<?php echo e(asset('img/home/user.svg')); ?>" >  </a>
                                    </li> 
                                    <?php endif; ?>

                                    <li class="nav-item ">
                                        <cart ref="cart" href="<?php echo e(route('web.carrito')); ?>" img="<?php echo e(asset('img/home/carrito.svg')); ?>"/>
                                    </li>
                                </ul>
                            </div>
                    </div>
                </div>

                <nav>
                    <div class="container" style="display: flex; justify-content: center;">
                        
                            

                            <button class="nav-btn d-flex d-md-none" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fas fa-bars"></i></button>
                    
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.home')); ?>">Inicio</a>
                                            </li>
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'empresa' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.empresa')); ?>">Empresa</a>
                                            </li>
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.productos.productos')); ?>">Fogoneros</a>
                                            </li>
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'carrito' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.carrito')); ?>">Accesorios</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'preguntas frecuentes' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.preguntas_frecuentes')); ?>">Cocina</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>" > Galería</a>
                                            </li> 
                                            <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                                <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>" > Contacto</a>
                                            </li>                                      
                                        </div>
                                        <div class="modal-footer">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            

                            <div style="display: flex;">
                                <ul class="nav d-none d-md-flex" style="margin-right:60px;">
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'home' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.home')); ?>">Inicio</a>
                                    </li>
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'empresa' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.empresa')); ?>">Empresa</a>
                                    </li>
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'productos' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.productos.categoria',[$primerCategoriaFogoneros, 'Fogoneros'])); ?>">Fogoneros</a>
                                    </li>
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'carrito' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.carrito')); ?>">Accesorios</a>
                                    </li> 
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'preguntas frecuentes' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.preguntas_frecuentes')); ?>">Cocina</a>
                                    </li> 
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>" > Galería</a>
                                    </li> 
                                    <li class="nav-item <?php echo e($breadcrumb[0]['title'] == 'contacto' ? 'nav-item-active' : ''); ?>">
                                        <a class="nav-link" href="<?php echo e(route('web.contacto')); ?>" > Contacto</a>
                                    </li>
                                </ul>

                                
                            </div>
                    </div>
                </nav>  


                
        </header>


<!--FIN HEADER-->
    
        <main>
            
                <?php echo $__env->yieldContent('content'); ?>
            
        </main>

<!--INICIO FOOTER-->        

        <footer>

            <div class="footer-top">
                <a class="d-none d-md-flex" href="https://api.whatsapp.com/send?phone=<?php echo e($configuracion->wsp); ?>"  <?php echo e($configuracion->wsp ? 'target=”_blank”' : ''); ?> ><div class="border-wsp"> <i class="fab fa-whatsapp"> </i></div> </a>
            </div>
            
            <div class="footer-info d-none d-md-flex ">
                <div class="container footer-box" style="padding-top:0; padding-bottom:0;">
                    <div class="row">

                        <div class="col-3 d-none d-sm-none d-md-block beige" >
                            <img src="<?php echo e(asset(Storage::url($home->logo_footer))); ?>" style="width: 30%; margin-bottom:30px;">
                            <p><?php echo e($home->frase_footer); ?></p>
                            <div class="footer-redes" style="display: flex; ">
                                <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($red->url); ?>" <?php echo e($red->url ? 'target=”_blank”' : ''); ?>  ><?php echo $red->icono; ?></a>                             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div> 
                        </div>
                        <div class="col-9" style=" padding-top:74px;">

                            <div class="container" style="padding-right:0;">
                                <div class="row">
                                    <div class="col-4 d-none d-sm-none d-md-block" >
                                        <h5 >Secciones</h5>
            
                                        <div class="row">
                                            <div class="col-6 d-none d-sm-none d-md-block" >
                                                <p><a href="<?php echo e(route('web.home')); ?>" >Inicio</a></p>
                                                <p><a href="<?php echo e(route('web.productos.productos')); ?>" >Productos</a></p>
                                                <p><a href="<?php echo e(route('web.carrito')); ?>" >Carrito</a></p> 
                                                <p><a href="<?php echo e(route('web.carrito')); ?>" >Carrito</a></p> 
                                            </div>
                                            
                                            <div class="col-6 d-none d-sm-none d-md-block" >
                                                <p><a href="<?php echo e(route('web.videos')); ?>" >Videos</a></p>
                                                <p><a href="<?php echo e(route('web.productos.productos')); ?>" >Contacto</a></p> 
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col">
                                        <h5 >Suscribite al Newsletter</h5>

                                        <form method="POST" action="<?php echo e(route('web.email')); ?>" >
                                            <?php echo csrf_field(); ?>
                                            <div class="input-box newsletter" style="position: relative; margin-right:15px; justify-content:flex-end;">
                                                    <input type="text" placeholder="Ingresa tu email" name="email" id="nombreParaVincular" >
                                                    <button type="submit" class="orangeBg"> <i class="far fa-paper-plane"></i> </button>
                                            </div>
                                        </form>   
                                    </div>

                                    <div class="col" style="padding-left:0; padding-right:0;"> 
                                        <h5 >Contacto</h5>
                                        <div class="item-footer">
                                            <i class="fas fa-map-marker-alt"  style="margin-top: 4px; margin-right: 5px;"></i>
                                            <p style="line-height: 19px;"><?php echo e($configuracion->direccion); ?></p>
                                        </div>
                                        <div class="item-footer" style="">
                                            <i class="fas fa-phone-alt"></i>
                                            <p><?php echo $configuracion->tel; ?></p>
                                        </div> 
                                
                                        <div class=" item-footer" style="">
                                            <i class="fas fa-envelope" ></i> 
                                            <p><a href="mailto:<?php echo e($configuracion->email); ?>" target=”_blank”><?php echo e($configuracion->email); ?></a></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>             
            </div>
        </div>
        </footer>
        </div>
<!--FIN FOOTER-->    
<?php $__env->startSection('scripts'); ?>
<?php echo $__env->yieldSection(); ?>
<!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>


        <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
        
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\qunuy\resources\views/layouts/plantilla.blade.php ENDPATH**/ ?>