

<?php $__env->startSection('title','Preguntas Frecuentes'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-contacto section-login" style="margin-top:40px;">
    <div class="container">

        
            <div class="row">
                <div class="col-12 col-md-6">
                    <login target="<?php echo e(route('web.clientes.login')); ?>" ruta="<?php echo e(route('web.carrito')); ?>" ref="login" />
                </div>
                <div class="col-12 col-md-6" style="border-left: 1px solid lightgray;">
                    <registro target="<?php echo e(route('web.clientes.register')); ?>" ref="registro" />
                </div>
            </div>
        
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/login.blade.php ENDPATH**/ ?>