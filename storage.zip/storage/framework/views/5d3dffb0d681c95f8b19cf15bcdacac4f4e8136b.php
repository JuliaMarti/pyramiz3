

<?php $__env->startSection('title', strtoupper($producto->nombre) ); ?>

<?php $__env->startSection('content'); ?>


<!--INICIO PRODUCTO-->


<section class="section-categoria" >

    <div class="container">
        <div class="row">

            <section class="nav-categorias col-12 col-md-2">
                <div class="list-group list-group-flush">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->show): ?>
                        <a href="<?php echo e(route('web.productos.categoria', $item->id)); ?>" style="<?php echo e($categoria_id == $item->id ? 'background-color:#E8E8E8; color: #726D6E;' : 'color: #C7D52B;'); ?>" class="list-group-item list-group-item-action list-caracteristica"><?php echo e($item->nombre); ?></a>

                    <?php endif; ?>


                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item2->show && $item->id == $item2->categoria_id ): ?>
                            <a  href="<?php echo e(route('web.productos.producto',$item2)); ?>" class="list-group-item list-group-item-action list-trabajo" style="<?php echo e($producto->id == $item2->id ? 'background-color:#E8E8E8; color: #726D6E;' : 'color: #C7D52B; '); ?> padding-left:35px;" ><?php echo e($item2->nombre); ?></a>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <section class="section-equipo col-10">
                <div class="container" style="padding-left:3px">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <div class="">
                                <div class="img-trabajo" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen))); ?>); "></div>
                            </div>

                            <div class="container" style="padding-right:0; padding-left:0;">
                                <div class="row" style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2);">
                                    <?php $__currentLoopData = $producto->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="box-clase-mini col-3" style="background-image: url(<?php echo e(asset(Storage::url($item->imagen))); ?>); ">
                                    <div class="overlay"></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                        </div>
                        <div class="col-12 col-md-6" style="display: flex; flex-direction:column; justify-content:space-between">
                            <div>
                                <div class="tabla-trabajo" style="color: #C7D52B; font: normal normal 300 19px/24px Roboto Condensed;">
                                    <?php echo e($producto->nombre); ?>

                                </div>
                                <p> <?php echo e($producto->descripcion); ?></p>
                                <?php if($producto->oferta ): ?>
                                <spam style="text-decoration:line-through;"> $<?php echo e($producto->precio_oferta); ?></spam>
                                <?php endif; ?> $<?php echo e($producto->precio); ?>


                                <div>
                                    <input id="cantinput" class="text-uppercase vprodcomprarboton" style="background-color: white; color:black;width: 150px; border: 1px solid #bfbfbf;height: 35px;text-align: right;" min="1" value="1" type="number">
                                   
                                    <div class="row" style="">
                                        <div style="margin-left: 15px; padding: 5px;max-width: 293px;">
                                        <p  class="vprodnombre" style="font-weight: bold; font-size: 14px;"> FORMAS DE PAGO</p>

                                        <p style="color: black; font-size: 14px;line-height: 0.4"> <img src="http://www.gasessanmartin.com.ar/img/money.svg"> Efectivo</p>
                                        <p style="color: black; font-size: 14px;margin-bottom: 0px;line-height: 0.4"> <img src="http://www.gasessanmartin.com.ar/img/dolar.svg"> Transferencia Bancaria</p>

                                        <img src="http://www.gasessanmartin.com.ar/img/installments.png" style="width: 280px; height: 37px;">
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top: 10PX; ">
                                        <div style="margin-left: 15px; padding: 5px; min-width: 293px;">
                                            <p  class="vprodnombre" style="font-weight: bold; font-size: 14px;line-height: 0.4"> FORMAS DE ENVÍO</p>

                                            <p style="color: black; font-size: 14px;margin-bottom: 0px;">- Retiro en local (sin costo)</p>
                                            <p style="color: black; font-size: 14px;margin-bottom: 0px;">- A convenir (con costo)</p>
                                            <p style="color: black; font-size: 14px;margin-bottom: 0px;">- Expreso (Sin costo hasta expreso)</p>
                                        </div>
                                    </div>
                                    
                                    <button class="btn-comprar" > COMPRAR</button>
                                </div>
                            </div>

                        </div>
                    </div>
                    
                    <?php $__currentLoopData = $producto->secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($seccion->show): ?>
                            <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:40px;">
                                <div class="col-12" style="background-color: #C7D52B; padding-top:5px;"><h5><?php echo e($seccion->titulo); ?></h5></div>
                            </div>
                            <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); margin-top:44px;">
                                <div class="col-12 descripcion"> <?php echo $seccion->texto; ?> </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row"  style="padding-right: calc(var(--bs-gutter-x)/ 2);padding-left: calc(var(--bs-gutter-x)/ 2); display:flex; justify-content:center;">
                        <h5 class="col-12" style="font: normal normal bold 15px/20px Roboto Condensed;letter-spacing: 0.7px;color: #726D6E; margin-top:47px; margin-bottom:27px;">PRODUCTOS RELACIONADOS</h5>
                        
                        <?php if($relacionado_1): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$relacionado_1)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_1->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_1->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if($relacionado_2): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$relacionado_2)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_2->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_2->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                        <?php if($relacionado_3): ?>
                        <div class="col-12 col-md-4">
                            <a href="<?php echo e(route('web.trabajos.trabajo',$relacionado_3)); ?>" style="text-decoration: none">
                            <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($relacionado_3->imagen))); ?>); "></div>
                                
                            <div class="text-box-categorias">
                                <h4 style="margin-top:22px; text-transform:uppercase;" ><?php echo e($relacionado_3->nombre); ?></h4>
                            </div> 
                            </a>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
            </section>
        </div>
    </div>

</section>



<!--FIN PRODUCTO-->
<?php $__env->stopSection(); ?>


            
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/productos/producto.blade.php ENDPATH**/ ?>