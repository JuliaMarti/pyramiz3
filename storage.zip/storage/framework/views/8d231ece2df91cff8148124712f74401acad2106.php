

<?php $__env->startSection('title','Compra realizada con éxito'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-clientes">
    <div class="container">
        <div class="row">
            <h1>Gracias por su compra!</h1>
            <p>Le estará llegando un mail con los detalles de la orden.</p>
        <div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kart-cilpren\resources\views/web/success.blade.php ENDPATH**/ ?>