

<?php $__env->startSection('title','Equipos'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO SECCIÓN EQUIPOS-->        
<section class="section-nuestros-productos">
    <div class="container">

        <div class="row">
            <form class="container">
                <div class="row">
                <div class="form-check col">
                    <input class="form-check-input" type="checkbox" id="disabledFieldsetCheck">
                    <label class="form-check-label" for="disabledFieldsetCheck">
                    EN VENTA
                    </label>
                </div>

                <div class="form-check col">
                    <input class="form-check-input" type="checkbox" id="disabledFieldsetCheck">
                    <label class="form-check-label" for="disabledFieldsetCheck">
                    EN ALQUILER
                    </label>
                </div>

                <div class="mb-3 col-3">
                    <select id="disabledSelect" class="form-select">
                        <option>CLASE</option>
                    </select>
                </div>
    
                <div class="mb-3 col-3">
                    <select id="disabledSelect" class="form-select">
                        <option>ALTURA DE TRABAJO</option>
                    </select>
                </div>

                <div class="mb-3 col-3">
                    <select id="disabledSelect" class="form-select">
                        <option>TIPO DE COMBUSTIÓN</option>
                    </select>
                </div>
                </div>
            </form>
        </div>

        <div class="row" style="margin-top: 22px; margin-bottom:84px;">
            <?php $__currentLoopData = $clases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($clase->show): ?>

                    <div class="col-12 col-md-4">
                        <a href="#" style="text-decoration: none">
                            <div class="box-clase">
                                <div class="img-border-equipos" style="background-image: url(<?php echo e(asset(Storage::url($clase->imagen))); ?>); "></div>
                                <p class="nombre-clase"><?php echo e($clase->nombre); ?></p>
                            </div>
                        </a>
                    </div>
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!--FIN SECCIÓN EQUIPOS-->        

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\pyramiz\resources\views/web/equipos.blade.php ENDPATH**/ ?>