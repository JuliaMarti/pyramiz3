

<?php $__env->startSection('title','Laser Factory'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->
<div id="carouselExampleIndicators" class="carousel carousel-home c-home slide d-none d-md-block" data-bs-ride="carousel">
    
    <div class="carousel-indicators" >
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="carousel-inner">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " style="background-image: url(<?php echo e(asset(Storage::url($imagen->imagen))); ?>)">
                        
                        <div class="carousel-overlay"></div>
                        
                        <div class="carousel-caption d-none d-md-block carousel-texto">
                            <h2><?php echo e($imagen->texto); ?></h2>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<!--FIN CAROUSEL-INICIO-->

        

<!--INICIO SECCIÓN PRODUCTOS-->


<section class="section-home-categorias"> 
    <h3 style="margin-top:40px; margin-bottom:35px;">PRODUCTOS DESTACADOS</h3>
    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($producto->destacado): ?>

                    <div class="col-12 col-md-3" style="margin-bottom:50px ">
                        <a href="<?php echo e(route('web.productos.producto',$producto)); ?>" style="text-decoration: none">
                        <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($producto->imagen))); ?>); "></div>
                            
                        <div class="text-box-categorias">
                            <h4 ><?php echo e($producto->nombre); ?></h4>
                        </div> 
                        </a>
                    </div>
                    
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<!--FIN SECCIÓN PRODUCTOS-->


<!--INICIO SECCIÓN TRABAJOS-->


        <section class="section-home-categorias"> 
            <h3 style="margin-top:40px; margin-bottom:35px;">TRABAJOS REALIZADOS</h3>
            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($trabajo->home): ?>

                            <div class="col-12 col-md-3" style="margin-bottom:50px ">
                                <a href="<?php echo e(route('web.trabajos.trabajo',$trabajo)); ?>" style="text-decoration: none">
                                <div class="img-border-categorias img-active" style="background-image: url(<?php echo e(asset(Storage::url($trabajo->imagen))); ?>); "></div>
                                    
                                <div class="text-box-categorias">
                                    <h4 ><?php echo e($trabajo->nombre); ?></h4>
                                </div> 
                                </a>
                            </div>
                            
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>

<!--FIN SECCIÓN TRABAJOS-->



        <?php if($home->seccion_foto_show): ?>
                <div class="imagen-seccion " style="background-image: url(<?php echo e(asset(Storage::url($home->seccion_foto_imagen))); ?>);">
                    <div class="container">
                        <p><?php echo e($home->seccion_foto_texto); ?></p>
                        
                        <button class="btn-mas-info col-md-2"> Más información</button>
                    </div>
                    
                </div>
        <?php endif; ?>       


<!--INICIO SECCIÓN REPRESENTANTES-->

        <section class="section-home-clientes d-none d-md-block" > 
            <div class="container">
                <h3 style="margin-bottom:38px;">NUESTROS CLIENTES</h3>
                <?php $cantidadRepresentantes = count($clientes) ?>

                <div id="Cfooter" class="carousel carousel-clientes slide" data-bs-ride="carousel">
                    
                    <div class="carousel-indicators" style="bottom: -60px !important; ">

                    <?php $__currentLoopData = $clientes->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <button type="button"  style="background-color:#C7D52B;""  data-bs-target="#Cfooter" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel d-none d-md-block" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>

                    <div class="carousel-inner">
                            <?php $__currentLoopData = $clientes->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " >
                                        <div class="row">

                                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($cliente->show): ?>
                                                    <div class="col-2" style="maring-bottom 1px;">
                                                            <div class=" img-border-grey "  style="background-image: url(<?php echo e(asset(Storage::url($cliente->imagen))); ?>)">
                                                                <!--<div class="overlay"></div>-->
                                                            </div>
                                                    </div>                                      
                                                    <?php endif; ?>

                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laser-factory\resources\views/web/index.blade.php ENDPATH**/ ?>