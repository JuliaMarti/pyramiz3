

<?php $__env->startSection('title','Pyramiz'); ?>

<?php $__env->startSection('content'); ?>

<!--INICIO CAROUSEL-INICIO-->
<div id="carouselExampleIndicators" class="carousel carousel-home slide d-none d-md-block" data-bs-ride="carousel">
    
    <div class="carousel-indicators">
    <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <button type="button" data-bs-target="#carouselExampleIndicators" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="carousel-inner">
            <?php $__currentLoopData = $imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> " style="background-image: url(<?php echo e(asset(Storage::url($imagen->imagen))); ?>)">
                        
                        <div class="carousel-overlay"></div>
                        
                        <div class="carousel-caption d-none d-md-block carousel-texto">
                            <h2><?php echo e($imagen->titulo); ?></h2>
                            <h3><?php echo e($imagen->subtitulo); ?></h3>

                            <p><?php echo e($imagen->texto); ?></p>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<!--FIN CAROUSEL-INICIO-->

        



<!--INICIO SECCIÓN SERVICIOS-->


        <section class="section-home-categorias"> 
            <h3>Nuestras Categorías</h3>
            <hr style="border: 0.5px solid #000000; margin-bottom:35px;">
            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($categoria->home): ?>

                            <div class="col-12 col-md-4" style="margin-bottom:50px ">
                                <div class="img-border-categorias" style="background-image: url(<?php echo e(asset(Storage::url($categoria->imagen))); ?>); "></div>
                                    
                                <div class="text-box-categorias">
                                    <h4><?php echo e($categoria->nombre); ?></h4>
                                </div> 
                                
                            </div>

                            
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </section>

<!--FIN SECCIÓN SERVICIOS-->



        <?php if($home->seccion_1_show): ?>
                <div class="imagen-seccion" style="background-image: url(<?php echo e(asset(Storage::url($home->seccion_1_imagen))); ?>);">

                </div>
        <?php endif; ?>       


        
        <?php if($home->seccion_2_show): ?>
                <div class="imagen-seccion" style="background-image: url(<?php echo e(asset(Storage::url($home->seccion_2_imagen))); ?>); ">

                </div>
        <?php endif; ?>   
<!--INICIO SECCIÓN REPRESENTANTES-->

        <section class="section-home-representantes d-none d-md-block"> 
            <div class="container">

                <?php $cantidadRepresentantes = count($clientes) ?>

                <div id="Cfooter" class="carousel carousel-representantes slide" data-bs-ride="carousel">
                    
                    <div class="carousel-indicators">

                    <?php $__currentLoopData = $clientes->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <button type="button" data-bs-target="#Cfooter" class="<?php echo e($loop->first ? 'active' : ''); ?> btn-carousel d-none d-md-block" data-bs-slide-to="<?php echo e($key); ?>" <?php echo e($loop->first ? 'aria-current="true"' : ''); ?>  aria-label="Slide <?php echo e($key); ?>"></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    </div>

                    <div class="carousel-inner">
                            <?php $__currentLoopData = $clientes->chunk(6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?> ">
                                        <div class="row">

                                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <?php if($cliente->show): ?>
                                                    
                                                            <div class="col-2 img-representante"  style="background-image: url(<?php echo e(asset(Storage::url($cliente->imagen))); ?>)">

                                                            </div>
                                                                                                    
                                                    <?php endif; ?>

                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\mundo-hierro\resources\views/web/index.blade.php ENDPATH**/ ?>