

<?php $__env->startSection('title','Videos'); ?>

<?php $__env->startSection('content'); ?>


<section class="section-videos">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($video->show): ?>

                    <div class="col-12 col-md-4 video" >
                        <iframe width="100%" height="251px"src="https://www.youtube.com/embed/<?php echo e($video->link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        
                        <h5><?php echo e($video->titulo); ?></h5>
                    </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam-cnc\resources\views/web/videos.blade.php ENDPATH**/ ?>