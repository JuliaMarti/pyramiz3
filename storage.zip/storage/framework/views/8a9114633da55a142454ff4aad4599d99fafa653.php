

<?php $__env->startSection('title','Modificar diámetro'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-11">
            <a style ="color:grey;" href="<?php echo e(route('productos.edit', $producto)); ?>"><i class="fas fa-arrow-circle-left" style ="color:grey; margin-right:6px;"></i>Volver al producto</a>

            <div class="card" style="margin-top:15px;">

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="<?php echo e(route('diametrosP.update', [$diametro,$producto])); ?>" enctype="multipart/form-data" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Orden</label>
                                    <input type="text" name="orden" value="<?php echo e(old('orden',$diametro->orden)); ?>" class="form-control" placeholder="Orden">
                                </div>
                            </div>

                            <div class="form-group col-md-4">
                                <label>Tamaño</label>
                                <input  type="number" name="tamano" value="<?php echo e(old('tamano',$diametro->tamano)); ?>" class="form-control">
                            </div>

                            <div class="form-check ">
                                <input class="form-check-input" type="checkbox" <?php echo e(old('show',$diametro->show) == 1 ? 'checked' : ''); ?> name="show" value="1">
                                <label class="form-check-label">Mostrar</label>
                            </div>


                            <div class="form-group col-md-4">
                                <label>Precio (sin diámetro)</label>
                                <input step=".01" type="number" name="precio" value="<?php echo e(old('precio',$diametro->precio)); ?>" class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                                <label>Precio anterior (sin diámetro)</label>
                                <input type="number" step=".01" name="precio_anterior" value="<?php echo e(old('precio_anterior',$diametro->precio_anterior)); ?>" class="form-control">
                            </div>

                            <div class="form-group">
                                <label><h4 class="primer-h4">Tabla</h4></label>
                                <hr>
                                <textarea class="form-control summernote" name="tabla"  rows="4"><?php echo e(old('tabla',$diametro->tabla)); ?></textarea>
                            </div>


                            <button type="submit" class="btn btn-primary mb-2">Actualizar diámetro</button>

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\qunuy\resources\views/diametros_p/edit.blade.php ENDPATH**/ ?>